"""Start StudyFlow so your phone and other laptops on the SAME Wi-Fi can open it.
Run:  python run_on_phone.py   then open the phone address it prints.
Only use this on a network you trust: anyone on it can reach the login page."""
import socket

from app import app


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # no data is sent; this only finds your Wi-Fi address
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


if __name__ == "__main__":
    print(f"\nOn this laptop:  http://127.0.0.1:5000\nOn your phone:   http://{lan_ip()}:5000  (same Wi-Fi)\n")
    app.run(host="0.0.0.0", port=5000, debug=False)  # debug stays off when others can connect
