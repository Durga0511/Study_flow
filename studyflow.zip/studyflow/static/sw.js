// Minimal service worker: makes StudyFlow installable. It never stores your pages or data;
// if the server cannot be reached it only shows a small "offline" page.
const CACHE = "studyflow-shell-v1";
self.addEventListener("install", (e) => {
    e.waitUntil(caches.open(CACHE).then((c) => c.add("/offline")).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", (e) => {
    if (e.request.mode === "navigate") {
        e.respondWith(fetch(e.request).catch(() => caches.match("/offline")));
    }
});
