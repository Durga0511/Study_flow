// Setup wizard: shows one step at a time, validates it, then submits everything once.
(function () {
    const form = document.getElementById("setup-form");
    const steps = Array.from(document.querySelectorAll(".step"));
    const $ = (id) => document.getElementById(id);
    let current = 0;

    // ----- dates and countdown -----
    function today() { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }
    function parseDate(text) {
        const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
        if (!m) return null;
        const d = new Date(+m[1], +m[2] - 1, +m[3]);
        return d.getMonth() === +m[2] - 1 ? d : null;
    }
    function daysLeft(text) {
        const d = parseDate(text);
        return d ? Math.round((d - today()) / 86400000) : null;
    }
    function plural(n, word) { return n + " " + word + (n === 1 ? "" : "s"); }
    const dateFormat = { weekday: "long", day: "numeric", month: "long", year: "numeric" };

    function showCountdown() {
        const n = daysLeft($("exam_date").value);
        const d = parseDate($("exam_date").value);
        $("today-text").textContent = today().toLocaleDateString(undefined, dateFormat);
        $("exam-text").textContent = d ? d.toLocaleDateString(undefined, dateFormat) : "not chosen yet";
        let msg;
        if (n === null) msg = "Choose a valid exam date to see your countdown.";
        else if (n < 0) msg = "That date has already passed. Please choose a future date.";
        else if (n === 0) msg = "Your exam is today. Good luck!";
        else {
            msg = "Your exam is in " + plural(n, "day") + "!";
            if (n >= 7) msg += " That is " + plural(Math.floor(n / 7), "week") + (n % 7 ? " and " + plural(n % 7, "day") : "") + ".";
        }
        $("countdown-msg").textContent = msg;
    }

    // ----- reading answers -----
    function checked(name) {
        const r = form.querySelector('input[name="' + name + '"]:checked');
        return r ? r.value : null;
    }
    function number(id) { const v = $(id).value.trim(); return v === "" ? NaN : Number(v); }
    function dailyMinutes() {
        const c = checked("daily");
        if (c === null) return NaN;
        return c === "custom" ? number("daily-h") * 60 + (number("daily-m") || 0) : Number(c) * 60;
    }
    function focusMinutes() {
        const c = checked("focus");
        if (c === null) return NaN;
        return c === "custom" ? number("focus-custom") : Number(c);
    }

    function validate(i) {
        if (i === 0) {
            if (!$("exam_name").value.trim()) return "Please enter your exam name.";
            const n = daysLeft($("exam_date").value);
            if (n === null) return "Please choose a valid exam date.";
            if (n < 0) return "The exam date cannot be in the past.";
        }
        if (i === 1) {
            const m = dailyMinutes();
            if (!Number.isInteger(m) || m < 15 || m > 960) return "Pick 1 to 6 hours, or enter a custom time between 15 minutes and 16 hours.";
        }
        if (i === 2) {
            const m = focusMinutes();
            if (!Number.isInteger(m) || m < 5 || m > 180) return "Pick a focus length, or enter 5 to 180 minutes.";
            if (m > dailyMinutes()) return "Your focus stretch cannot be longer than your daily study time.";
        }
        if (i === 3 && !checked("short")) return "Please choose a short break length.";
        if (i === 4 && !checked("long")) return "Please choose a long break length.";
        if (i === 5 && !$("start_time").value) return "Please choose your daily start time.";
        return "";
    }

    // ----- long break suggestion -----
    function updateLongHint() {
        const suggested = focusMinutes() >= 60 ? 60 : 30;
        $("long-hint").textContent = suggested === 60
            ? "Because you focus for 60 minutes or more, a 60-minute long break is suggested. You can override it."
            : "With shorter focus sessions, a 30-minute long break usually works well. You can override it.";
        if (form.dataset.firstTime === "1" && !form.dataset.longTouched) {
            form.querySelector('input[name="long"][value="' + suggested + '"]').checked = true;
        }
    }

    // ----- wizard navigation -----
    function show(i) {
        current = i;
        steps.forEach((s, k) => { s.hidden = k !== i; });
        $("progress-bar").style.width = ((i + 1) / steps.length * 100) + "%";
        $("progress-label").textContent = "Step " + (i + 1) + " of " + steps.length;
        $("back-btn").hidden = i === 0;
        $("next-btn").textContent = i === steps.length - 1 ? "Finish setup" : "Continue";
        $("step-error").textContent = "";
        if (i === 4) updateLongHint();
    }
    function next() {
        const err = validate(current);
        if (err) { $("step-error").textContent = err; return; }
        if (current < steps.length - 1) { show(current + 1); return; }
        $("daily_minutes").value = dailyMinutes();
        $("focus_minutes").value = focusMinutes();
        $("short_break").value = checked("short");
        $("long_break").value = checked("long");
        $("long_break_after").value = $("long-after").value;
        form.submit();
    }

    // ----- pre-fill saved answers (also used when editing later) -----
    function preset(name, value) {
        const radio = form.querySelector('input[name="' + name + '"][value="' + value + '"]');
        if (radio) { radio.checked = true; return true; }
        const custom = form.querySelector('input[name="' + name + '"][value="custom"]');
        if (custom) custom.checked = true;
        return false;
    }
    function syncCustom() {
        $("daily-custom").hidden = checked("daily") !== "custom";
        $("focus-custom-wrap").hidden = checked("focus") !== "custom";
    }
    const saved = form.dataset;
    const daily = Number(saved.daily);
    if (!(daily % 60 === 0 && preset("daily", daily / 60))) {
        preset("daily", "custom");
        $("daily-h").value = Math.floor(daily / 60);
        $("daily-m").value = daily % 60;
    }
    if (!preset("focus", saved.focus)) $("focus-custom").value = saved.focus;
    preset("short", saved.short);
    preset("long", saved.long);
    $("long-after").value = saved.after;

    form.addEventListener("change", (e) => {
        if (e.target.name === "long") form.dataset.longTouched = "1";
        syncCustom();
    });
    form.addEventListener("submit", (e) => { e.preventDefault(); next(); });
    $("back-btn").addEventListener("click", () => show(current - 1));
    $("exam_date").addEventListener("input", showCountdown);
    syncCustom();
    showCountdown();
    show(0);
})();
