// Focus timer. It lives on EVERY page: its state is saved in localStorage, so it keeps running
// while you move around the site (and in other tabs). The Timer page only adds the controls.
(function () {
    const cfgEl = document.getElementById("timer-config");
    if (!cfgEl) return;                                   // not logged in
    const cfg = JSON.parse(cfgEl.textContent);
    const KEY = "studyflow.timer." + cfg.uid;             // one timer per account
    const GRACE = 10 * 60 * 1000;                         // a round that ended over 10 minutes ago is not counted
    const LABELS = { focus: "Focus", short: "Short break", long: "Long break" };
    const $ = (id) => document.getElementById(id);
    const page = $("timer");                              // only exists on the Timer page
    const baseTitle = document.title;
    let today = page ? Number(page.dataset.today) : 0;

    const fresh = (mode, cycle) => ({ mode, total: cfg[mode] * 60, left: cfg[mode] * 60, running: false, endAt: 0, cycle, token: null, sid: null, title: "" });
    function load() {
        try {
            const s = JSON.parse(localStorage.getItem(KEY));
            if (s && cfg[s.mode] && (s.sid || s.total === cfg[s.mode] * 60)) return s;   // ignore state saved with old settings
        } catch (e) { /* start fresh */ }
        return fresh("focus", 0);
    }
    let st = load();
    const save = () => localStorage.setItem(KEY, JSON.stringify(st));
    const remaining = () => (st.running ? Math.max(0, Math.ceil((st.endAt - Date.now()) / 1000)) : st.left);
    const fmt = (s) => String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");

    // Small floating timer on every other page
    const mini = document.createElement("a");
    mini.id = "mini-timer";
    mini.className = "mini-timer";
    mini.href = "/timer";
    mini.hidden = true;
    document.body.appendChild(mini);

    function render() {
        const left = remaining();
        const active = st.running || st.left < st.total;
        document.title = st.running ? (st.mode === "focus" ? "" : "") + fmt(left) + " · " + baseTitle : baseTitle;
        mini.hidden = !active || !!page;
        mini.textContent = LABELS[st.mode] + "  " + fmt(left) + (st.running ? "" : " (paused)");
        if (!page) return;
        $("time").textContent = fmt(left);
        $("mode").textContent = LABELS[st.mode];
        $("task").textContent = st.sid ? "" + st.title : "";
        $("ring").style.setProperty("--pct", (100 - (left / st.total) * 100).toFixed(1));
        $("ring").classList.toggle("running", st.running);
        $("cycle").textContent = "Focus rounds finished: " + st.cycle + " · long break after every " + cfg.after;
        $("start").textContent = st.running ? "Pause" : st.left < st.total ? "Resume" : "Start";
    }
    function toast(message) {
        const el = document.createElement("div");
        el.className = "toast-pop";
        el.textContent = message;
        document.body.appendChild(el);
        setTimeout(() => el.remove(), 4000);
    }
    function alertUser(mode) {
        if (page) { $("ring").classList.add("alert"); setTimeout(() => $("ring").classList.remove("alert"), 2500); }
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            osc.frequency.value = 660;
            osc.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.4);
        } catch (e) { /* sound is optional */ }
        const message = mode === "focus" ? "Focus round complete! Take a break" : "Break over. Ready to focus?";
        toast(message);
        if (cfg.notify && "Notification" in window && Notification.permission === "granted") new Notification("StudyFlow", { body: message });
    }
    // Every focus run has its own token, so the server can never record the same run twice.
    function record(minutes, token, sid, done) {
        if (!token || minutes < 1) return;
        const csrf = document.querySelector('meta[name="csrf"]').content;
        const params = { csrf_token: csrf, token: token, minutes: String(minutes) };
        if (sid) { params.session_id = String(sid); params.done = done ? "1" : "0"; }
        const body = new URLSearchParams(params);
        fetch(cfg.url, { method: "POST", body }).then((r) => r.json()).then((d) => {
            if (d.ok && !d.duplicate) {
                today += minutes;
                if (page) $("today").textContent = today;
                toast("+" + d.xp + " XP earned");
            }
        }).catch(() => toast("Could not save this round. Check your connection."));
    }
    function start() {
        if (st.mode === "focus" && !st.token) st.token = Date.now().toString(16) + Math.random().toString(16).slice(2, 12);
        st.endAt = Date.now() + st.left * 1000;
        st.running = true;
        save();
        render();
    }
    function pause() { st.left = remaining(); st.running = false; save(); render(); }
    function finish(stale) {
        const was = st;
        if (stale) {
            st = fresh("focus", was.cycle);
            save();
            render();
            toast("Your last round ended while you were away, so it was not counted.");
            return;
        }
        alertUser(was.mode);
        if (was.mode === "focus") {
            record(was.sid ? Math.round(was.total / 60) : cfg.focus, was.token, was.sid, true);
            const cycle = was.cycle + 1;
            st = fresh(cycle % cfg.after === 0 ? "long" : "short", cycle);
            start();                                      // breaks start by themselves
        } else {
            st = fresh("focus", was.cycle);
            save();
            render();
        }
    }
    function skip() {
        const left = remaining();
        if (st.mode === "focus") { record(Math.floor((st.total - left) / 60), st.token, st.sid, false); st = fresh("short", st.cycle); }
        else st = fresh("focus", st.cycle);
        save();
        render();
    }
    function tick() {
        if (st.running) {
            const saved = load();                         // another tab may already have moved on
            if (!saved.running || saved.mode !== st.mode || saved.endAt !== st.endAt) { st = saved; render(); return; }
            if (Date.now() >= st.endAt) { finish(Date.now() - st.endAt > GRACE); return; }
        }
        render();
    }

    if (page) {
        $("start").addEventListener("click", () => {
            if (cfg.notify && "Notification" in window && Notification.permission === "default") Notification.requestPermission();
            st.running ? pause() : start();
        });
        $("reset").addEventListener("click", () => {
            const keep = st.sid ? { sid: st.sid, title: st.title, total: st.total } : null;   // a session timer stays tied to its session
            st = fresh(st.mode, st.cycle);
            if (keep) { Object.assign(st, keep); st.left = keep.total; }
            save();
            render();
        });
        $("skip").addEventListener("click", skip);
    }
    if (page && page.dataset.sid) {                       // opened with "Start studying" in the planner
        const sid = Number(page.dataset.sid);
        if (st.sid !== sid) {
            if (st.running) toast("Another round is running. Finish or reset it first.");
            else {
                st = fresh("focus", st.cycle);
                st.total = st.left = Number(page.dataset.minutes) * 60;
                st.sid = sid;
                st.title = page.dataset.title;
                start();                                  // the timer starts as soon as you start studying
            }
        }
    }
    window.addEventListener("storage", (e) => { if (e.key === KEY) { st = load(); render(); } });
    document.addEventListener("visibilitychange", tick);
    setInterval(tick, 500);
    tick();
})();
