// Light/dark toggle. Remembered in this browser and, when logged in, saved to your account
// so every phone and laptop you log in on shows the same theme.
document.getElementById("theme-toggle").addEventListener("click", () => {
    const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    localStorage.setItem("theme", next);
    if (document.body.dataset.auth === "1") {
        const csrf = document.querySelector('meta[name="csrf"]').content;
        fetch("/settings/theme", { method: "POST", body: new URLSearchParams({ csrf_token: csrf, theme: next }) }).catch(() => {});
    }
});
