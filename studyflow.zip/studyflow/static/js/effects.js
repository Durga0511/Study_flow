// Subtle motion only: content fades up as it scrolls into view, and numbers count up once.
(function () {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const $$ = (selector) => Array.from(document.querySelectorAll(selector));

    // Cards appear one after another as you scroll
    const groups = new Map();
    const reveals = $$(".reveal");
    reveals.forEach((el) => {
        const n = groups.get(el.parentNode) || 0;
        el.style.setProperty("--d", Math.min(n, 6) * 0.08 + "s");
        groups.set(el.parentNode, n + 1);
    });
    if ("IntersectionObserver" in window && !reduce) {
        const io = new IntersectionObserver((entries) => entries.forEach((e) => {
            if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
        }), { threshold: 0.12 });
        reveals.forEach((el) => io.observe(el));
    } else {
        reveals.forEach((el) => el.classList.add("in"));
    }

    // Numbers count up once; stat rows slide in one by one
    $$("[data-count]").forEach((el) => {
        const target = Number(el.dataset.count);
        if (!Number.isFinite(target) || reduce) return;
        const start = performance.now();
        (function tick(now) {
            const t = Math.min(1, (now - start) / 1200);
            el.textContent = Math.round(target * (1 - Math.pow(1 - t, 3)));
            if (t < 1) requestAnimationFrame(tick);
        })(start);
    });
    $$(".stat").forEach((el, i) => el.style.setProperty("--i", i));
})();
