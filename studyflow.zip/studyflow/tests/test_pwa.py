import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("STUDYFLOW_DB", os.path.join(tempfile.mkdtemp(), "test.db"))
import app as studyflow  # noqa: E402
from tests.test_planner import ready_user  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class AppInstallTests(unittest.TestCase):
    def test_manifest_icons_service_worker_and_offline_page(self):
        c = studyflow.app.test_client()
        r = c.get("/manifest.webmanifest")
        self.assertIn("manifest+json", r.content_type)
        data = json.loads(r.data)
        self.assertEqual((data["display"], data["short_name"]), ("standalone", "StudyFlow"))
        for icon in data["icons"]:
            png = c.get(icon["src"]).data
            self.assertEqual(png[:8], b"\x89PNG\r\n\x1a\n")
        self.assertEqual(c.get("/static/icons/apple-touch-icon.png").status_code, 200)
        sw = c.get("/sw.js")
        self.assertIn("javascript", sw.content_type)
        self.assertEqual(sw.headers["Service-Worker-Allowed"], "/")
        self.assertEqual(c.get("/offline").status_code, 200)

    def test_timer_runs_on_every_page_for_logged_in_users_only(self):
        anon = studyflow.app.test_client().get("/login").get_data(as_text=True)
        self.assertNotIn("timer-config", anon)
        self.assertIn('rel="manifest"', anon)
        c = ready_user("t1@x.com")
        for url in ("/dashboard", "/planner", "/subjects", "/calendar", "/settings", "/timer"):
            page = c.get(url).get_data(as_text=True)
            self.assertIn("js/timer.js", page, url)
            self.assertIn('"focus": 45', page, url)
        self.assertEqual(page.count("js/timer.js"), 1)  # the Timer page does not load it twice

    @unittest.skipUnless(shutil.which("node"), "Node.js is not installed")
    def test_timer_keeps_running_across_pages_and_tabs(self):
        result = subprocess.run(["node", os.path.join(ROOT, "tests", "timer_persistence.js")], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("timer persistence OK", result.stdout)


if __name__ == "__main__":
    unittest.main()
