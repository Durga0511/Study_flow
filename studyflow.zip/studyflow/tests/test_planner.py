import os
import sys
import tempfile
import unittest
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("STUDYFLOW_DB", os.path.join(tempfile.mkdtemp(), "test.db"))
from tests.test_setup import good_form  # noqa: E402
from tests.test_subjects import good, new_user, post, rows  # noqa: E402


def ready_user(email):
    c = new_user(email)
    post(c, "/setup", **good_form())  # 180 min/day, 45 min focus, starts 06:00
    post(c, "/subjects/new", **good(name="Maths", topics="Algebra\nGeometry\nCalculus", hours="3"))
    return c


def my_sessions(email, where=""):
    return rows("SELECT * FROM study_sessions WHERE user_id = (SELECT id FROM users WHERE email = ?) " + where
                + " ORDER BY session_date, start_time", email)


class PlannerTests(unittest.TestCase):
    def test_login_required(self):
        import app as studyflow
        c = studyflow.app.test_client()
        self.assertEqual(c.get("/planner").status_code, 302)
        self.assertEqual(post(c, "/planner/generate").status_code, 302)

    def test_generate_saves_a_valid_plan(self):
        c = ready_user("p1@x.com")
        self.assertIn("No study plan yet", c.get("/planner").get_data(as_text=True))
        self.assertEqual(post(c, "/planner/generate").status_code, 302)
        plan = my_sessions("p1@x.com")
        exam = date.today() + timedelta(days=45)
        self.assertTrue(plan and all(date.fromisoformat(r["session_date"]) < exam for r in plan))
        for d in {r["session_date"] for r in plan}:
            day = [r for r in plan if r["session_date"] == d and r["kind"] in ("study", "revision", "practice")]
            self.assertLessEqual(sum(r["duration_min"] for r in day), 180)
        later_days = sorted({r["session_date"] for r in plan} - {date.today().isoformat()})
        for d in later_days[:3]:  # every other day starts exactly at the start time from setup
            self.assertEqual([r for r in plan if r["session_date"] == d][0]["start_time"], "06:00")
        first = next(r for r in plan if r["kind"] == "study")
        page = c.get(f"/planner?day={first['session_date']}").get_data(as_text=True)
        self.assertIn("Maths", page)
        self.assertIn("Not Started", page)

    def test_checklist_progress_history_and_notes(self):
        c = ready_user("p2@x.com")
        post(c, "/planner/generate")
        row = next(r for r in my_sessions("p2@x.com") if r["kind"] == "study")
        sid, day = row["id"], row["session_date"]
        for _ in range(3):  # repeated requests must not double-count
            self.assertEqual(post(c, f"/sessions/{sid}/status", status="completed").status_code, 302)
        history = rows("SELECT minutes FROM study_history WHERE session_id = ?", sid)
        self.assertEqual([h["minutes"] for h in history], [row["duration_min"]])
        self.assertIn("1 / ", c.get(f"/planner?day={day}").get_data(as_text=True))
        post(c, f"/sessions/{sid}/status", status="in_progress")
        self.assertEqual(rows("SELECT minutes FROM study_history WHERE session_id = ?", sid), [])
        self.assertEqual(post(c, f"/sessions/{sid}/status", status="bogus").status_code, 400)
        post(c, f"/sessions/{sid}/notes", notes="Revise formulas first")
        self.assertIn("Revise formulas first", c.get(f"/planner?day={day}").get_data(as_text=True))
        breaks = rows("SELECT id FROM study_sessions WHERE kind LIKE '%break' AND user_id = "
                      "(SELECT id FROM users WHERE email = 'p2@x.com') LIMIT 1")
        self.assertEqual(post(c, f"/sessions/{breaks[0]['id']}/status", status="completed").status_code, 400)

    def test_regenerating_keeps_completed_sessions(self):
        c = ready_user("p3@x.com")
        post(c, "/planner/generate")
        row = next(r for r in my_sessions("p3@x.com") if r["kind"] == "study")
        post(c, f"/sessions/{row['id']}/status", status="completed")
        post(c, "/planner/generate")
        kept = rows("SELECT status FROM study_sessions WHERE id = ?", row["id"])
        self.assertEqual(kept[0]["status"], "completed")
        same_day = [r for r in my_sessions("p3@x.com") if r["session_date"] == row["session_date"] and r["kind"] == "study"]
        self.assertLessEqual(sum(r["duration_min"] for r in same_day), 180)  # the daily limit still counts the completed session
        day = [r for r in my_sessions("p3@x.com") if r["session_date"] == row["session_date"]]
        for a, b in zip(day, day[1:]):
            self.assertLessEqual(a["end_time"], b["start_time"])

    def test_routine_style_repeats_the_same_timetable_every_day(self):
        c = ready_user("p7@x.com")
        post(c, "/planner/generate", style="routine")
        plan = my_sessions("p7@x.com")
        days = sorted({r["session_date"] for r in plan})
        pattern = lambda d: [(r["start_time"], r["end_time"], r["kind"]) for r in plan if r["session_date"] == d]
        self.assertEqual(pattern(days[1]), pattern(days[2]))
        self.assertEqual(sum(r["duration_min"] for r in plan if r["session_date"] == days[1] and r["kind"] == "study"), 180)
        self.assertEqual(pattern(days[1])[0][0], "06:00")  # the start time from setup

    def test_start_studying_runs_the_timer_and_completing_it_ticks_the_session(self):
        c = ready_user("p8@x.com")
        post(c, "/planner/generate")
        study = [r for r in my_sessions("p8@x.com") if r["kind"] == "study"]
        row, row2 = study[0], study[1]
        r = post(c, f"/sessions/{row['id']}/start")
        self.assertIn(f"/timer?session={row['id']}", r.headers["Location"])
        status = lambda i: rows("SELECT status FROM study_sessions WHERE id = ?", i)[0]["status"]
        self.assertEqual(status(row["id"]), "in_progress")
        page = c.get(f"/timer?session={row['id']}").get_data(as_text=True)
        self.assertIn(f'data-sid="{row["id"]}"', page)
        self.assertIn(f'data-minutes="{row["duration_min"]}"', page)
        for _ in range(2):  # repeated requests are saved once
            done = post(c, "/timer/complete", token="a1b2c3d4e5f60718", minutes=str(row["duration_min"]),
                        session_id=str(row["id"]), done="1")
            self.assertEqual(done.status_code, 200)
        self.assertEqual(status(row["id"]), "completed")
        history = rows("SELECT minutes, source FROM study_history WHERE session_id = ?", row["id"])
        self.assertEqual([(h["minutes"], h["source"]) for h in history], [(row["duration_min"], "timer")])
        post(c, f"/sessions/{row2['id']}/start")  # skipped early: minutes are saved, the session is not ticked
        post(c, "/timer/complete", token="d1b2c3d4e5f60718", minutes="10", session_id=str(row2["id"]), done="0")
        self.assertEqual(status(row2["id"]), "in_progress")
        self.assertEqual(post(c, "/timer/complete", token="c1b2c3d4e5f60718", minutes="46",
                              session_id=str(row["id"]), done="1").status_code, 400)
        brk = next(r for r in my_sessions("p8@x.com") if r["kind"].endswith("break"))
        self.assertEqual(post(c, f"/sessions/{brk['id']}/start").status_code, 400)
        other = ready_user("p9@x.com")
        self.assertEqual(post(other, f"/sessions/{row['id']}/start").status_code, 404)
        self.assertEqual(post(other, "/timer/complete", token="b1b2c3d4e5f60718", minutes="10",
                              session_id=str(row["id"]), done="1").status_code, 404)
        self.assertNotIn(f'data-sid="{row2["id"]}"', other.get(f"/timer?session={row2['id']}").get_data(as_text=True))

    def test_users_are_isolated_and_dashboard_shows_progress(self):
        a, b = ready_user("p4@x.com"), ready_user("p5@x.com")
        post(a, "/planner/generate")
        row = my_sessions("p4@x.com")[0]
        self.assertEqual(post(b, f"/sessions/{row['id']}/status", status="completed").status_code, 404)
        self.assertEqual(post(b, f"/sessions/{row['id']}/notes", notes="x").status_code, 404)
        self.assertNotIn("Maths —", b.get(f"/planner?day={row['session_date']}").get_data(as_text=True))
        self.assertIn("Today's Progress", a.get("/dashboard").get_data(as_text=True))

    def test_exam_over_gives_a_warning_not_a_crash(self):
        c = new_user("p6@x.com")
        post(c, "/setup", **good_form(exam_date=date.today().isoformat()))
        post(c, "/subjects/new", **good())
        r = post(c, "/planner/generate")
        self.assertEqual(r.status_code, 302)
        self.assertIn("exam is today", c.get("/planner").get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
