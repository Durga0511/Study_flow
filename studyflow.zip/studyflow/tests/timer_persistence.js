// Simulates moving between pages (and opening a second tab) while the timer runs.
const fs = require("fs"), path = require("path"), assert = require("assert");
const code = fs.readFileSync(path.join(__dirname, "..", "static", "js", "timer.js"), "utf8");
const CFG = { uid: 7, focus: 45, short: 10, long: 30, after: 3, notify: false, url: "/timer/complete" };
const KEY = "studyflow.timer.7";
let now = 1_000_000_000_000;
const store = {}, fetches = [];
const localStorage = { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
const el = () => ({ style: { setProperty() {} }, classList: { toggle() {}, add() {}, remove() {} }, appendChild() {}, remove() {}, addEventListener() {} });

function openPage() {   // what happens when a page (or another tab) loads timer.js
    const intervals = [];
    const document = { title: "Dashboard", body: el(), createElement: el, addEventListener() {},
        querySelector: () => ({ content: "csrf-token" }),
        getElementById: (id) => (id === "timer-config" ? { textContent: JSON.stringify(CFG) } : null) };
    const fetch = (url, opts) => { fetches.push({ url, body: String(opts.body) }); return Promise.resolve({ json: () => Promise.resolve({ ok: true, xp: 70 }) }); };
    new Function("document", "localStorage", "window", "fetch", "setInterval", "clearInterval", "setTimeout", "Date", code)(
        document, localStorage, { addEventListener() {} }, fetch, (fn) => { intervals.push(fn); return 1; }, () => {}, () => {}, { now: () => now });
    return { tick: () => intervals.forEach((f) => f()) };
}
const put = (s) => { store[KEY] = JSON.stringify(Object.assign({ total: 2700, left: 2700, cycle: 0, running: true }, s)); };
const state = () => JSON.parse(store[KEY]);

// 1. A round is running (30 s left) and the user opens another page: it is still running.
put({ mode: "focus", endAt: now + 30000, token: "abc123def456abc1" });
let page = openPage(); page.tick();
assert.strictEqual(fetches.length, 0);
assert.strictEqual(state().running, true);
// 2. Time passes; the round ends on whatever page the user is on: saved once, short break starts.
now += 31000; page.tick();
assert.strictEqual(fetches.length, 1);
assert.ok(fetches[0].body.includes("token=abc123def456abc1") && fetches[0].body.includes("minutes=45"));
assert.deepStrictEqual([state().mode, state().running, state().cycle], ["short", true, 1]);
// 3. A second tab sharing the same storage must not record it again.
openPage().tick(); page.tick();
assert.strictEqual(fetches.length, 1);
// 4. Every 3rd focus round is followed by the long break.
put({ mode: "focus", endAt: now + 1000, cycle: 2, token: "ffffffffffff0001" });
page = openPage(); now += 2000; page.tick();
assert.strictEqual(state().mode, "long");
assert.strictEqual(fetches.length, 2);
// 5. A round that ended long ago (computer was off) is not counted.
put({ mode: "focus", endAt: now - 11 * 60000, token: "ffffffffffff0002" });
page = openPage(); page.tick();
assert.strictEqual(fetches.length, 2);
assert.deepStrictEqual([state().mode, state().running], ["focus", false]);
// 6. A paused timer stays paused and keeps its time.
put({ mode: "focus", running: false, left: 1000, endAt: 0 });
page = openPage(); now += 60000; page.tick();
assert.deepStrictEqual([state().running, state().left], [false, 1000]);
// 7. A round started with "Start studying" finishes: its session is completed on the server, with its own length.
put({ mode: "focus", total: 1800, left: 1800, endAt: now + 1000, sid: 12, title: "Maths — Algebra", token: "eeeeeeeeeeee0001" });
page = openPage(); now += 2000; page.tick();
const last = fetches[fetches.length - 1].body;
assert.ok(last.includes("session_id=12") && last.includes("done=1") && last.includes("minutes=30"), last);
assert.strictEqual(state().sid, null);
console.log("timer persistence OK");
