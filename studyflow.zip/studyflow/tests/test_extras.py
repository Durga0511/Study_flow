import os
import sys
import tempfile
import unittest
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("STUDYFLOW_DB", os.path.join(tempfile.mkdtemp(), "test.db"))
import gamify  # noqa: E402
from tests.test_planner import ready_user  # noqa: E402
from tests.test_subjects import new_user, post, rows  # noqa: E402

T = date(2026, 3, 10)


class GamifyTests(unittest.TestCase):
    def test_streaks(self):
        d = lambda n: T - timedelta(days=n)
        self.assertEqual(gamify.streaks({T, d(1), d(2), d(5)}, T), (3, 3))
        self.assertEqual(gamify.streaks({d(1), d(2)}, T), (2, 2))   # today not studied yet: streak still alive
        self.assertEqual(gamify.streaks({d(2), d(3)}, T), (0, 2))   # a full day was missed
        self.assertEqual(gamify.streaks(set(), T), (0, 0))

    def test_xp_levels_stage_badges_and_quests(self):
        fresh = gamify.summary({}, 0, 0, 0, T)
        self.assertEqual((fresh["xp"], fresh["level"], fresh["stage"][1]), (0, 1, "Dragon Egg"))
        self.assertFalse(any(b["unlocked"] for b in fresh["badges"]))
        self.assertTrue(fresh["next_hint"])
        busy = gamify.summary({T - timedelta(days=i): 120 for i in range(7)}, 30, 3, 1, T)
        self.assertEqual(busy["xp"], 840 + 750)
        self.assertGreaterEqual(busy["level"], 4)
        self.assertEqual(busy["streak"], 7)
        self.assertTrue(all(b["unlocked"] for b in busy["badges"] if b["name"] != "Elder Flame"))
        self.assertEqual([q[1] for q in busy["quests"]], [True, True, True])
        self.assertTrue(0 <= busy["pct"] <= 100)


class AppExtrasTests(unittest.TestCase):
    def test_timer_saves_once_and_feeds_the_dragon(self):
        c = ready_user("e1@x.com")  # focus stretch is 45 minutes
        self.assertEqual(c.get("/timer").status_code, 200)
        for _ in range(3):
            r = post(c, "/timer/complete", token="abc123def456abc1", minutes="30")
            self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["duplicate"], True)
        self.assertEqual([h["minutes"] for h in rows("SELECT minutes FROM study_history WHERE source = 'timer' AND user_id = "
                                                       "(SELECT id FROM users WHERE email = 'e1@x.com')")], [30])
        for bad in ({"token": "x", "minutes": "30"}, {"token": "aaaaaaaaaaaa", "minutes": "0"},
                    {"token": "bbbbbbbbbbbb", "minutes": "46"}, {"token": "cccccccccccc", "minutes": "x"}):
            self.assertEqual(post(c, "/timer/complete", **bad).status_code, 400, bad)
        page = c.get("/dashboard").get_data(as_text=True)
        self.assertIn("55 XP", page)             # 30 minutes + 25 bonus XP for the finished round
        self.assertIn("<small>LEVEL</small><b>1</b>", page)
        self.assertIn("1-day streak", page)
        self.assertIn("First Flame", page)

    def test_new_dashboard_shows_egg_and_locked_badges(self):
        page = ready_user("e2@x.com").get("/dashboard").get_data(as_text=True)
        self.assertIn("Dragon Egg", page)
        self.assertIn("achv-tile off", page)
        self.assertIn("Next achievement", page)

    def test_calendar_and_bad_month_values(self):
        c = ready_user("e3@x.com")
        post(c, "/planner/generate")
        self.assertIn("dot up", c.get("/calendar").get_data(as_text=True))
        for month in ("garbage", "2026-13", "1000-01", "9999-12", ""):
            self.assertEqual(c.get(f"/calendar?month={month}").status_code, 200, month)

    def test_settings_profile_theme_password_and_isolation(self):
        c = ready_user("e4@x.com")
        self.assertEqual(c.get("/settings").status_code, 200)
        post(c, "/settings/profile", name="New Name", theme="light", notifications="on")
        self.assertIn('"light"', c.get("/dashboard").get_data(as_text=True))
        self.assertIn("New Name", c.get("/dashboard").get_data(as_text=True))
        self.assertEqual(post(c, "/settings/theme", theme="dark").status_code, 204)
        self.assertEqual(post(c, "/settings/theme", theme="neon").status_code, 400)
        post(c, "/settings/password", current="wrong", new="newpassword1", confirm="newpassword1")
        post(c, "/logout")
        self.assertEqual(post(c, "/login", email="e4@x.com", password="newpassword1").status_code, 200)  # still old password
        post(c, "/login", email="e4@x.com", password="password1")
        post(c, "/settings/password", current="password1", new="newpassword1", confirm="newpassword1")
        post(c, "/logout")
        self.assertEqual(post(c, "/login", email="e4@x.com", password="newpassword1").status_code, 302)
        anon = new_user("e5@x.com")
        anon.get("/logout")
        import app as studyflow
        self.assertEqual(post(studyflow.app.test_client(), "/settings/theme", theme="dark").status_code, 302)

    def test_delete_account_needs_password_and_word_and_removes_everything(self):
        c = ready_user("e6@x.com")
        post(c, "/planner/generate")
        post(c, "/settings/delete", password="password1", confirm="delete")
        post(c, "/settings/delete", password="wrong", confirm="DELETE")
        self.assertEqual(len(rows("SELECT id FROM users WHERE email = 'e6@x.com'")), 1)
        self.assertEqual(post(c, "/settings/delete", password="password1", confirm="DELETE").status_code, 302)
        self.assertEqual(rows("SELECT id FROM users WHERE email = 'e6@x.com'"), [])
        self.assertEqual(rows("SELECT id FROM subjects WHERE name = 'Maths' AND user_id NOT IN (SELECT id FROM users)"), [])
        self.assertEqual(post(c, "/login", email="e6@x.com", password="password1").status_code, 200)

    def test_phone_runner_finds_an_address(self):
        import run_on_phone
        self.assertRegex(run_on_phone.lan_ip(), r"^\d+\.\d+\.\d+\.\d+$")


if __name__ == "__main__":
    unittest.main()
