import os
import sys
import unittest
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scheduler import BREAKS, generate_plan, to_minutes  # noqa: E402

PREFS = dict(daily_minutes=180, focus_minutes=45, short_break=10, long_break=30, long_break_after=3, start_time="09:00")
TODAY = date(2026, 1, 1)
_ids = iter(range(1, 10000))


def subject(name, topics=("A", "B"), hours=0, difficulty="Medium", priority="Medium", done=()):
    return dict(id=next(_ids), name=name, difficulty=difficulty, priority=priority, est_minutes=int(hours * 60),
                topics=[dict(id=next(_ids), name=t, completed=int(t in done)) for t in topics])


def plan(subjects, days=10, prefs=None, **kw):
    return generate_plan(prefs or PREFS, TODAY + timedelta(days=days), TODAY, 0, subjects, **kw)


def study_minutes(sessions, name=None):
    return sum(s["minutes"] for s in sessions if s["kind"] == "study" and (name is None or s["title"].startswith(name)))


class SchedulerTests(unittest.TestCase):
    def setUp(self):
        self.subjects = [subject("Maths", ("Algebra", "Calculus"), difficulty="Hard", priority="High"),
                         subject("History", ("Wars",), difficulty="Easy", priority="Low"), subject("Physics")]
        self.result = plan(self.subjects)
        self.sessions = self.result["sessions"]

    def test_day_starts_at_start_time_and_fills_the_daily_hours(self):
        day = [s for s in self.sessions if s["date"] == TODAY.isoformat()]
        self.assertEqual((day[0]["start"], day[0]["end"]), ("09:00", "09:45"))
        self.assertEqual((day[1]["kind"], day[1]["start"], day[1]["end"]), ("short_break", "09:45", "09:55"))
        self.assertEqual([s["kind"] for s in day[:6]], ["study", "short_break", "study", "short_break", "study", "long_break"])
        for d in {s["date"] for s in self.sessions[:]} - {(TODAY + timedelta(days=i)).isoformat() for i in (8, 9)}:
            rows = [s for s in self.sessions if s["date"] == d]
            self.assertEqual(sum(s["minutes"] for s in rows if s["kind"] not in BREAKS), 180, d)  # every hour you gave is used

    def test_no_overlaps_no_trailing_breaks_nothing_after_exam_and_limit_respected(self):
        for d in {s["date"] for s in self.sessions}:
            rows = [s for s in self.sessions if s["date"] == d]
            self.assertNotIn(rows[-1]["kind"], BREAKS)
            self.assertLessEqual(sum(s["minutes"] for s in rows if s["kind"] not in BREAKS), 180)
            for a, b in zip(rows, rows[1:]):
                self.assertLessEqual(to_minutes(a["end"]), to_minutes(b["start"]))
            self.assertLess(date.fromisoformat(d), TODAY + timedelta(days=10))

    def test_important_subjects_get_more_time_and_every_topic_is_reached(self):
        learning = [s for s in self.sessions if date.fromisoformat(s["date"]) < TODAY + timedelta(days=8)]
        self.assertGreater(study_minutes(learning, "Maths"), 1.3 * study_minutes(learning, "Physics"))
        self.assertGreater(study_minutes(learning, "Physics"), study_minutes(learning, "History"))
        topics = {s["topic_id"] for s in learning if s["topic_id"]}
        self.assertEqual(len(topics), 5)
        self.assertEqual(self.result["warnings"], [])

    def test_hours_given_for_subjects_are_used_as_relative_shares(self):
        r = plan([subject("Big", hours=6), subject("Small", hours=3)])["sessions"]
        ratio = study_minutes(r, "Big") / study_minutes(r, "Small")
        self.assertTrue(1.6 < ratio < 2.4, ratio)

    def test_routine_repeats_the_same_timetable_every_day(self):
        subs = [subject("A", ("a1", "a2", "a3"), difficulty="Hard"), subject("B", ("b1",)), subject("C", ("c1", "c2"), priority="Low")]
        rows = plan(subs, days=12, routine=True)["sessions"]
        def pattern(i):
            d = (TODAY + timedelta(days=i)).isoformat()
            return [(s["start"], s["end"], s["kind"], s["title"].split(" — ")[0]) for s in rows if s["date"] == d]
        self.assertEqual(pattern(0), pattern(1))
        self.assertEqual(pattern(1), pattern(5))
        self.assertNotEqual([s["title"] for s in rows if s["date"] == TODAY.isoformat()],
                            [s["title"] for s in rows if s["date"] == (TODAY + timedelta(days=1)).isoformat()])  # topics rotate

    def test_last_days_are_revision_and_practice(self):
        last = [s for s in self.sessions if s["date"] == (TODAY + timedelta(days=8)).isoformat()]
        self.assertTrue(last and all(s["kind"] in ("revision", "practice") or s["kind"] in BREAKS for s in last))
        self.assertTrue(any(s["kind"] == "practice" for s in self.sessions))

    def test_subjects_without_topics_are_still_scheduled(self):
        rows = plan([subject("Tamil", topics=())])["sessions"]
        self.assertTrue(all(s["title"] == "Tamil" and s["topic_id"] is None for s in rows if s["kind"] == "study"))
        self.assertEqual(study_minutes(rows), 8 * 180)

    def test_warnings_and_edge_cases(self):
        crowded = plan([subject("Big", tuple(f"T{i}" for i in range(60)))], days=3)
        self.assertTrue(any("could not be reached" in w for w in crowded["warnings"]))
        self.assertIn("exam is today", plan(self.subjects, days=0)["warnings"][0])
        self.assertIn("Add your subjects", plan([])["warnings"][0])
        self.assertTrue(any("no time could be reserved" in w for w in plan(self.subjects, days=2)["warnings"]))

    def test_finished_topics_are_skipped_and_finished_subjects_only_get_revision(self):
        r = plan([subject("Done", ("x", "y"), done=("x", "y")), subject("Todo", ("p", "q"), done=("p",))])
        study = [s for s in r["sessions"] if s["kind"] == "study"]
        self.assertTrue(study and all(s["title"] == "Todo — q" for s in study))
        self.assertTrue(any(s["title"] == "Revision — Done" for s in r["sessions"]))
        every = plan([subject("Done", ("x",), done=("x",))])
        self.assertIn("Every topic is complete", every["warnings"][0])

    def test_completed_sessions_are_preserved_and_today_never_starts_in_the_past(self):
        done = {TODAY.isoformat(): (60, "10:00")}
        today = [s for s in plan(self.subjects, completed=done)["sessions"] if s["date"] == TODAY.isoformat()]
        self.assertGreaterEqual(to_minutes(today[0]["start"]), to_minutes("10:00"))
        self.assertEqual(sum(s["minutes"] for s in today if s["kind"] not in BREAKS), 120)

    def test_today_follows_the_start_time_timetable_and_never_schedules_the_past(self):
        def run(now):
            return generate_plan(PREFS, TODAY + timedelta(days=10), TODAY, now, self.subjects)
        morning = run(8 * 60)  # before the start time: the full day, exactly from 09:00
        self.assertEqual([s["start"] for s in morning["sessions"][:2]], ["09:00", "09:45"])
        self.assertEqual(morning["warnings"], [])
        midday = run(10 * 60)  # 10:00: the 09:55 slot is running now, earlier ones are gone
        today = [s for s in midday["sessions"] if s["date"] == TODAY.isoformat()]
        self.assertEqual((today[0]["kind"], today[0]["start"], today[0]["end"]), ("study", "09:55", "10:40"))
        self.assertTrue(all(to_minutes(s["end"]) > 10 * 60 for s in today))
        self.assertIn("past your 9:00 AM start time", midday["warnings"][0])
        night = run(21 * 60)  # nothing left today: the plan starts tomorrow, exactly at the start time
        self.assertEqual([s for s in night["sessions"] if s["date"] == TODAY.isoformat()], [])
        self.assertEqual(night["sessions"][0]["date"], (TODAY + timedelta(days=1)).isoformat())
        self.assertEqual(night["sessions"][0]["start"], "09:00")
        self.assertIn("past your 9:00 AM start time", night["warnings"][0])


if __name__ == "__main__":
    unittest.main()
