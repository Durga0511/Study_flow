import os
import sys
import tempfile
import unittest
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("STUDYFLOW_DB", os.path.join(tempfile.mkdtemp(), "test.db"))
import app as studyflow  # noqa: E402


def good_form(**changes):
    form = {"exam_name": "Final Exam", "exam_date": (date.today() + timedelta(days=45)).isoformat(),
            "exam_description": "Semester 8", "daily_minutes": "180", "focus_minutes": "45",
            "short_break": "10", "long_break": "30", "long_break_after": "3", "start_time": "06:00"}
    form.update(changes)
    return form


class SetupTests(unittest.TestCase):
    def new_user(self, email):
        c = studyflow.app.test_client()
        self.post(c, "/signup", name="Setup User", email=email, password="password1", confirm="password1")
        return c

    def post(self, c, url, **data):
        with c.session_transaction() as s:
            s["csrf_token"] = "t"
        data["csrf_token"] = "t"
        return c.post(url, data=data)

    def test_first_login_goes_to_wizard_then_dashboard(self):
        c = self.new_user("w1@x.com")
        self.assertIn("/setup", c.get("/dashboard").headers["Location"])
        self.assertEqual(c.get("/setup").status_code, 200)
        self.assertEqual(self.post(c, "/setup", **good_form()).status_code, 302)
        page = c.get("/dashboard")
        self.assertEqual(page.status_code, 200)
        self.assertIn(b"Final Exam", page.data)
        self.assertIn(b"45", page.data)
        self.assertIn(b"6:00 AM", page.data)

    def test_invalid_answers_are_rejected(self):
        c = self.new_user("w2@x.com")
        past = (date.today() - timedelta(days=1)).isoformat()
        for bad in ({"exam_date": past}, {"exam_date": "nonsense"}, {"exam_name": " "},
                    {"daily_minutes": "5"}, {"focus_minutes": "200"}, {"focus_minutes": "240", "daily_minutes": "180"},
                    {"short_break": "7"}, {"long_break": "45"}, {"start_time": "25:99"}):
            r = self.post(c, "/setup", **good_form(**bad))
            self.assertEqual(r.status_code, 200, bad)
        self.assertEqual(c.get("/dashboard").status_code, 302)

    def test_settings_survive_logout_and_users_are_separate(self):
        c = self.new_user("w3@x.com")
        self.post(c, "/setup", **good_form(exam_name="Mine"))
        self.post(c, "/logout")
        self.post(c, "/login", email="w3@x.com", password="password1")
        self.assertIn(b"Mine", c.get("/dashboard").data)
        other = self.new_user("w4@x.com")
        self.assertEqual(other.get("/dashboard").status_code, 302)
        self.post(other, "/setup", **good_form(exam_name="Theirs"))
        self.assertNotIn(b"Mine", other.get("/dashboard").data)
        self.assertNotIn(b"Theirs", c.get("/dashboard").data)

    def test_exam_can_be_edited_later(self):
        c = self.new_user("w5@x.com")
        self.post(c, "/setup", **good_form())
        self.post(c, "/setup", **good_form(exam_name="Updated Exam", focus_minutes="60", long_break="60"))
        self.assertIn(b"Updated Exam", c.get("/dashboard").data)


if __name__ == "__main__":
    unittest.main()


class EffectsTests(unittest.TestCase):
    def test_confetti_flag_shows_once_and_effects_are_linked(self):
        s = SetupTests()
        c = s.new_user("fx@x.com")
        s.post(c, "/setup", **good_form())
        first = c.get("/dashboard").get_data(as_text=True)
        self.assertIn("data-celebrate", first)
        self.assertIn("js/effects.js", first)
        self.assertNotIn("data-celebrate", c.get("/dashboard").get_data(as_text=True))
        home = studyflow.app.test_client().get("/").get_data(as_text=True)
        self.assertIn("hero-grid", home)
        self.assertNotIn("floater", home)  # no playful floating decorations on the landing page
