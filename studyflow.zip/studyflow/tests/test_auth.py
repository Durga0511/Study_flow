import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["STUDYFLOW_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")
import app as studyflow  # noqa: E402


class AuthTests(unittest.TestCase):
    def setUp(self):
        self.c = studyflow.app.test_client()

    def post(self, url, **data):
        with self.c.session_transaction() as s:
            s["csrf_token"] = "t"
        data["csrf_token"] = "t"
        return self.c.post(url, data=data)

    def test_pages_load(self):
        for url in ("/", "/login", "/signup"):
            self.assertEqual(self.c.get(url).status_code, 200)

    def test_dashboard_requires_login(self):
        self.assertEqual(self.c.get("/setup").status_code, 302)

    def test_signup_login_logout_and_duplicates(self):
        r = self.post("/signup", name="Test User", email="a@b.com", password="password1", confirm="password1")
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.c.get("/setup").status_code, 200)
        self.post("/logout")
        self.assertEqual(self.c.get("/setup").status_code, 302)
        self.assertEqual(self.post("/login", email="a@b.com", password="wrongpass").status_code, 200)
        self.assertEqual(self.post("/login", email="a@b.com", password="password1").status_code, 302)
        self.assertEqual(self.c.get("/setup").status_code, 200)
        r = self.post("/signup", name="Other", email="A@B.com", password="password1", confirm="password1")
        self.assertIn(b"already registered", r.data)

    def test_missing_csrf_token_is_rejected(self):
        r = self.c.post("/login", data={"email": "a@b.com", "password": "x"})
        self.assertEqual(r.status_code, 400)

    def test_password_is_hashed(self):
        self.post("/signup", name="Hash Me", email="h@b.com", password="password1", confirm="password1")
        db = studyflow.database.get_db()
        row = db.execute("SELECT password_hash FROM users WHERE email = 'h@b.com'").fetchone()
        db.close()
        self.assertNotEqual(row["password_hash"], "password1")


if __name__ == "__main__":
    unittest.main()
