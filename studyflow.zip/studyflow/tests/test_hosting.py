import os
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("STUDYFLOW_DB", os.path.join(tempfile.mkdtemp(), "test.db"))
import app as studyflow  # noqa: E402
from tests.test_subjects import new_user, post  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def zone_ok(name):
    try:
        ZoneInfo(name)
        return True
    except Exception:
        return False


class HostingTests(unittest.TestCase):
    @unittest.skipUnless(zone_ok("Pacific/Kiritimati") and zone_ok("Pacific/Pago_Pago"), "no time zone database")
    def test_each_visitor_sees_today_in_their_own_time_zone(self):
        c = new_user("h1@x.com")
        for name in ("Pacific/Kiritimati", "Pacific/Pago_Pago"):  # 25 hours apart
            c.set_cookie("tz", name)
            expected = datetime.now(ZoneInfo(name)).strftime("%A, %d %B %Y")
            self.assertIn(expected, c.get("/planner").get_data(as_text=True), name)

    def test_bad_time_zone_cookies_never_break_the_site(self):
        c = new_user("h2@x.com")
        for value in ("Nope/Zone", "../../etc/passwd", "", "a" * 500, "UTC;x"):
            c.set_cookie("tz", value)
            self.assertEqual(c.get("/planner").status_code, 200, value)
        self.assertEqual(c.get("/").status_code, 200)

    def test_security_headers_and_no_caching_of_pages(self):
        r = studyflow.app.test_client().get("/login")
        self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(r.headers["X-Frame-Options"], "DENY")
        self.assertEqual(r.headers["Cache-Control"], "no-store")
        self.assertNotEqual(studyflow.app.test_client().get("/static/css/style.css").headers.get("Cache-Control"), "no-store")

    def test_https_and_proxy_settings_for_hosting(self):
        script = ("import app; c = app.app.test_client(); "
                  "r = c.get('/login', headers={'X-Forwarded-Proto': 'https'}); "
                  "print(app.app.config['SESSION_COOKIE_SECURE'], r.headers.get('Strict-Transport-Security'))")
        env = dict(os.environ, STUDYFLOW_HTTPS="1", STUDYFLOW_PROXY="1", STUDYFLOW_DB=os.path.join(tempfile.mkdtemp(), "h.db"))
        out = subprocess.run([sys.executable, "-c", script], cwd=ROOT, env=env, capture_output=True, text=True)
        self.assertEqual(out.returncode, 0, out.stderr)
        self.assertEqual(out.stdout.split(), ["True", "max-age=31536000"])
        self.assertFalse(studyflow.app.config.get("SESSION_COOKIE_SECURE"))  # plain http still works on your own laptop

    def test_repeated_wrong_passwords_lock_the_login_for_a_while(self):
        new_user("h3@x.com")
        c = studyflow.app.test_client()
        for _ in range(5):
            self.assertEqual(post(c, "/login", email="h3@x.com", password="wrong-pass").status_code, 200)
        locked = post(c, "/login", email="h3@x.com", password="password1")  # even the right password waits
        self.assertEqual(locked.status_code, 429)
        self.assertIn(b"Too many failed attempts", locked.data)
        self.assertEqual(post(c, "/login", email="someone-else@x.com", password="x").status_code, 200)

    def test_successful_login_resets_the_counter(self):
        new_user("h4@x.com")
        c = studyflow.app.test_client()
        for _ in range(4):
            post(c, "/login", email="h4@x.com", password="wrong-pass")
        self.assertEqual(post(c, "/login", email="h4@x.com", password="password1").status_code, 302)
        post(c, "/logout")
        for _ in range(4):
            self.assertEqual(post(c, "/login", email="h4@x.com", password="wrong-pass").status_code, 200)


if __name__ == "__main__":
    unittest.main()
