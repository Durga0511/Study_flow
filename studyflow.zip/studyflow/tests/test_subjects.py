import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("STUDYFLOW_DB", os.path.join(tempfile.mkdtemp(), "test.db"))
import app as studyflow  # noqa: E402


def post(c, url, **data):
    with c.session_transaction() as s:
        s["csrf_token"] = "t"
    data["csrf_token"] = "t"
    return c.post(url, data=data)


def new_user(email):
    c = studyflow.app.test_client()
    post(c, "/signup", name="Sub User", email=email, password="password1", confirm="password1")
    return c


def rows(sql, *args):
    db = studyflow.database.get_db()
    try:
        return db.execute(sql, args).fetchall()
    finally:
        db.close()


def good(**changes):
    form = dict(name="Mathematics", difficulty="Hard", priority="High", hours="6",
                topics="Algebra\nGeometry\n\nCalculus", notes="Focus on proofs")
    form.update(changes)
    return form


class SubjectTests(unittest.TestCase):
    def test_login_required(self):
        c = studyflow.app.test_client()
        self.assertEqual(c.get("/subjects").status_code, 302)
        self.assertEqual(post(c, "/subjects/new", **good()).status_code, 302)

    def test_add_subject_with_topics_and_time_split(self):
        c = new_user("s1@x.com")
        self.assertEqual(post(c, "/subjects/new", **good()).status_code, 302)
        page = c.get("/subjects").get_data(as_text=True)
        self.assertIn("Mathematics", page)
        self.assertIn("0 of 3 topics done", page)
        self.assertEqual(len(rows("SELECT id FROM topics WHERE name IN ('Algebra', 'Geometry', 'Calculus')")), 3)
        # hours are optional: a subject without hours is planned automatically
        self.assertEqual(post(c, "/subjects/new", **good(name="Auto", hours="")).status_code, 302)
        self.assertEqual(rows("SELECT est_minutes FROM subjects WHERE name = 'Auto'")[0]["est_minutes"], 0)
        self.assertIn("auto time", c.get("/subjects").get_data(as_text=True))

    def test_validation_and_duplicates(self):
        c = new_user("s2@x.com")
        post(c, "/subjects/new", **good())
        for bad in ({"name": " "}, {"difficulty": "Insane"}, {"priority": "Max"}, {"hours": "0"},
                    {"hours": "abc"}, {"hours": "nan"}, {"name": "mathematics"}, {"topics": "x" * 101}):
            self.assertEqual(post(c, "/subjects/new", **good(**bad)).status_code, 200, bad)
        self.assertEqual(len(rows("SELECT id FROM subjects WHERE user_id = (SELECT id FROM users WHERE email = 's2@x.com')")), 1)

    def test_progress_edit_and_delete(self):
        c = new_user("s3@x.com")
        post(c, "/subjects/new", **good(name="Physics"))
        sid = rows("SELECT id FROM subjects WHERE name = 'Physics'")[0]["id"]
        post(c, f"/subjects/{sid}/topics", name="Optics")
        tid = rows("SELECT id FROM topics WHERE name = 'Algebra' AND subject_id = ?", sid)[0]["id"]
        post(c, f"/topics/{tid}/toggle", completed="1")
        self.assertIn("1 of 4 topics done", c.get("/subjects").get_data(as_text=True))
        post(c, f"/topics/{tid}/toggle")  # unticked checkbox sends nothing
        self.assertIn("0 of 4 topics done", c.get("/subjects").get_data(as_text=True))
        post(c, f"/subjects/{sid}/edit", **good(name="Physics 2", hours="3"))
        self.assertEqual(rows("SELECT est_minutes FROM subjects WHERE id = ?", sid)[0]["est_minutes"], 180)
        post(c, f"/topics/{tid}/delete")
        post(c, f"/subjects/{sid}/delete")
        self.assertEqual(rows("SELECT id FROM topics WHERE subject_id = ?", sid), [])

    def test_users_cannot_touch_each_others_data(self):
        a, b = new_user("s4@x.com"), new_user("s5@x.com")
        post(a, "/subjects/new", **good(name="Private"))
        sid = rows("SELECT id FROM subjects WHERE name = 'Private'")[0]["id"]
        tid = rows("SELECT id FROM topics WHERE subject_id = ?", sid)[0]["id"]
        self.assertNotIn("Private", b.get("/subjects").get_data(as_text=True))
        self.assertEqual(b.get(f"/subjects/{sid}/edit").status_code, 404)
        self.assertEqual(post(b, f"/subjects/{sid}/delete").status_code, 404)
        self.assertEqual(post(b, f"/subjects/{sid}/topics", name="Hack").status_code, 404)
        self.assertEqual(post(b, f"/topics/{tid}/toggle", completed="1").status_code, 404)
        self.assertEqual(post(b, f"/topics/{tid}/delete").status_code, 404)
        self.assertEqual(len(rows("SELECT id FROM subjects WHERE id = ?", sid)), 1)

    def test_html_in_names_is_escaped(self):
        c = new_user("s6@x.com")
        post(c, "/subjects/new", **good(name="<script>alert(1)</script>", topics="<b>x</b>"))
        page = c.get("/subjects").get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", page)
        self.assertIn("&lt;script&gt;", page)


if __name__ == "__main__":
    unittest.main()
