"""Dragon companion: XP, level, streak, quests and badges, all calculated from saved study history."""
from datetime import timedelta

XP_PER_SESSION = 25
STAGES = ((1, "Dragon Egg", "🥚"), (3, "Hatchling", "🐣"), (6, "Wyrmling", "🦎"), (10, "Fire Drake", "🐲"), (15, "Elder Dragon", "🐉"))
MESSAGES = ("A single focused session today keeps your streak alive.", "Consistency beats cramming. Protect today's first session.",
            "Start with the hardest topic while your focus is fresh.", "Small, steady sessions add up to exam-day confidence.",
            "Review what you studied yesterday before starting something new.", "Decide your first session now, then simply begin.")


def level_for(xp):
    return int((xp / 100) ** 0.5) + 1


def streaks(days, today):
    """Returns (current streak, best streak). The current streak stays alive until a full day is missed."""
    days = set(days)
    best = run = 0
    previous = None
    for d in sorted(days):
        run = run + 1 if previous and d - previous == timedelta(days=1) else 1
        best, previous = max(best, run), d
    current, d = 0, (today if today in days else today - timedelta(days=1))
    while d in days:
        current += 1
        d -= timedelta(days=1)
    return current, best


def summary(minutes_by_day, sessions, sessions_today, subjects_done, today):
    minutes = sum(minutes_by_day.values())
    xp = minutes + XP_PER_SESSION * sessions
    level = level_for(xp)
    floor, ceiling = 100 * (level - 1) ** 2, 100 * level ** 2
    streak, best = streaks(minutes_by_day.keys(), today)
    today_minutes = minutes_by_day.get(today, 0)
    defs = (("First Flame", "🔥", "Finish your first study session", sessions >= 1),
            ("Ember Trio", "⚡", "Study 3 days in a row", best >= 3),
            ("Week Warrior", "🛡️", "Study 7 days in a row", best >= 7),
            ("Hour Hoard", "💎", "Study for 10 hours in total", minutes >= 600),
            ("Scroll Keeper", "📜", "Finish 25 sessions", sessions >= 25),
            ("Dragon Slayer", "⚔️", "Complete every topic of one subject", subjects_done >= 1),
            ("Elder Flame", "👑", "Study for 50 hours in total", minutes >= 3000))
    badges = [{"name": n, "emoji": e, "hint": h, "unlocked": ok} for n, e, h, ok in defs]
    locked = [b for b in badges if not b["unlocked"]]
    return {
        "xp": xp, "level": level, "stage": [s for s in STAGES if level >= s[0]][-1],
        "pct": round((xp - floor) / (ceiling - floor) * 100), "to_next": ceiling - xp,
        "streak": streak, "best": best, "minutes": minutes, "sessions": sessions, "badges": badges,
        "next_hint": locked[0]["hint"] if locked else "",
        "quests": [("Complete 1 session", sessions_today >= 1, f"{min(sessions_today, 1)}/1"),
                   ("Complete 3 sessions", sessions_today >= 3, f"{min(sessions_today, 3)}/3"),
                   ("Study for 90 minutes", today_minutes >= 90, f"{min(today_minutes, 90)}/90 min")],
        "message": MESSAGES[today.toordinal() % len(MESSAGES)],
    }
