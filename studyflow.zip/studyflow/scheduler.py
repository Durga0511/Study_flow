"""Study plan generator. Plain Python (no Flask, no database) so it is easy to test.

How it works
1. You give subjects (and optionally their topics). No time is needed per topic.
2. Every study day is filled with your full daily hours, starting exactly at your start time
   (today shows the same timetable, minus any sessions that are already over):
   one session per focus stretch, a short break between sessions, and a long break after
   every N sessions. Breaks are never counted as study time.
3. Study time is shared between subjects by weight: priority and difficulty decide the
   weight (Hard/High subjects get more time). If you entered hours for a subject, those
   hours are compared between subjects instead (6 h gets twice the time of 3 h).
4. Each subject rotates through its own topics automatically.
5. The last ~20% of the days before the exam are kept for revision and practice tests.
   Nothing is scheduled on or after the exam date.
6. "Smart" lets the rotation continue from day to day. "Routine" repeats the same
   timetable every day (same times, same subjects); only the topic changes.
"""
from datetime import timedelta
from itertools import cycle

PRIORITY = {"Low": 1, "Medium": 2, "High": 3}
DIFFICULTY = {"Easy": 1, "Medium": 2, "Hard": 3}
BREAKS = ("short_break", "long_break")
MIN_SESSION = 10        # a day is closed when less than this many study minutes remain
REVISION_SHARE = 0.2    # share of the days before the exam kept for revision and practice


def to_minutes(text):
    hours, minutes = text.split(":")
    return int(hours) * 60 + int(minutes)


def clock(total):
    return f"{total // 60:02d}:{total % 60:02d}"


def ampm(total):
    hour, minute = divmod(total, 60)
    return f"{(hour % 12) or 12}:{minute:02d} {'AM' if hour < 12 else 'PM'}"


def score(subject):
    return PRIORITY[subject["priority"]] + DIFFICULTY[subject["difficulty"]]


def subject_weights(subjects):
    given = [s["est_minutes"] for s in subjects if s["est_minutes"] > 0]
    default = sum(given) / len(given) if given else 1.0
    return {s["name"]: (s["est_minutes"] if s["est_minutes"] > 0 else default) * score(s) / 4 for s in subjects}


class WeightedSupplier:
    """Hands out study sessions to subjects in proportion to their weights (smooth weighted round-robin)."""
    def __init__(self, entries):
        self.entries, self.used = entries, set()
        self.reset()

    def reset(self):
        self.credit = {e["name"]: 0.0 for e in self.entries}

    def empty(self):
        return not self.entries

    def take(self, limit):
        total = sum(e["weight"] for e in self.entries)
        for e in self.entries:
            self.credit[e["name"]] += e["weight"]
        pick = max(self.entries, key=lambda e: (self.credit[e["name"]], e["weight"]))
        self.credit[pick["name"]] -= total
        if pick["topics"]:
            topic_id, topic_name = pick["topics"][pick["cursor"] % len(pick["topics"])]
            pick["cursor"] += 1
            self.used.add(topic_id)
            title = f"{pick['name']} — {topic_name}"
        else:
            topic_id, title = None, pick["name"]
        return {"kind": "study", "title": title, "topic_id": topic_id, "minutes": limit}


class RevisionSupplier:
    """Alternates revision and practice-test sessions across all subjects."""
    def __init__(self, names):
        self.items = cycle([("revision", "Revision", n) for n in names] + [("practice", "Practice test", n) for n in names])

    def empty(self):
        return False

    def take(self, limit):
        kind, label, name = next(self.items)
        return {"kind": kind, "title": f"{label} — {name}", "topic_id": None, "minutes": limit}


def build_day(day, pos, daily_left, supplier, prefs):
    """Lay out one day starting at minute `pos`. Returns a list of sessions and breaks."""
    rows, count = [], 0
    while daily_left >= MIN_SESSION and not supplier.empty():
        limit = min(prefs["focus_minutes"], daily_left, 1439 - pos)
        if limit < MIN_SESSION:
            break
        item = supplier.take(limit)
        rows.append({"date": day.isoformat(), "start": clock(pos), "end": clock(pos + item["minutes"]), **item})
        pos += item["minutes"]
        daily_left -= item["minutes"]
        count += 1
        if daily_left >= MIN_SESSION and not supplier.empty():
            is_long = count % prefs["long_break_after"] == 0
            length = prefs["long_break"] if is_long else prefs["short_break"]
            rows.append({"date": day.isoformat(), "start": clock(pos), "end": clock(pos + length),
                         "kind": "long_break" if is_long else "short_break",
                         "title": "Long break" if is_long else "Short break", "topic_id": None, "minutes": length})
            pos += length
    while rows and rows[-1]["kind"] in BREAKS:  # never end a day with a break
        rows.pop()
    return rows


def generate_plan(prefs, exam_date, today, now_minutes, subjects, completed=None, routine=False):
    """prefs: daily_minutes, focus_minutes, short_break, long_break, long_break_after, start_time.
    subjects: dicts with id, name, difficulty, priority, est_minutes (0 = automatic) and
    topics: [{id, name, completed}].
    completed: {"YYYY-MM-DD": (minutes already completed, end time of the last completed session)}
    Returns {"sessions": [...], "warnings": [...]}."""
    completed = completed or {}
    total_days = (exam_date - timedelta(days=1) - today).days + 1  # last study day is the day before the exam
    if total_days < 1:
        return {"sessions": [], "warnings": ["Your exam is today or the date has passed. Update your exam date in Setup to build a plan."]}
    if not subjects:
        return {"sessions": [], "warnings": ["Add your subjects first, then generate your plan."]}

    warnings, entries = [], []
    weights = subject_weights(subjects)
    ordered = sorted(subjects, key=lambda s: (-score(s), s["name"].lower()))
    for s in ordered:
        pending = [(t["id"], t["name"]) for t in s["topics"] if not t["completed"]]
        if s["topics"] and not pending:
            continue  # every topic is done: this subject now only appears in revision
        entries.append({"name": s["name"], "weight": weights[s["name"]], "topics": pending, "cursor": 0})
    learner = WeightedSupplier(entries)
    revision = RevisionSupplier([s["name"] for s in ordered])
    if not entries:
        warnings.append("Every topic is complete. Your plan contains revision and practice only.")

    revision_days = max(1, round(total_days * REVISION_SHARE)) if total_days >= 4 else 0
    if revision_days == 0:
        warnings.append(f"Only {total_days} day(s) left before your exam, so no time could be reserved for revision.")
    start = to_minutes(prefs["start_time"])
    sessions = []
    for offset in range(total_days):
        day = today + timedelta(days=offset)
        learning = offset < total_days - revision_days
        if learning and learner.empty():
            continue
        if learning and routine:
            learner.reset()  # the same order every day
        done_minutes, last_end = completed.get(day.isoformat(), (0, None))
        pos = max(start, to_minutes(last_end) if last_end else 0)
        rows = build_day(day, pos, prefs["daily_minutes"] - done_minutes, learner if learning else revision, prefs)
        if offset == 0:  # today keeps the same timetable from your start time, minus what is already over
            kept = [r for r in rows if to_minutes(r["end"]) > now_minutes]
            while kept and kept[0]["kind"] in BREAKS:
                kept.pop(0)
            if any(r["kind"] not in BREAKS and to_minutes(r["end"]) <= now_minutes for r in rows):
                warnings.append(f"It is already past your {ampm(start)} start time, so today only has the sessions that "
                                f"have not finished yet. Every other day starts at {ampm(start)}.")
            rows = kept
        sessions += rows

    all_topics = {topic_id for e in entries for topic_id, _ in e["topics"]}
    missed = len(all_topics - learner.used)
    if missed:
        warnings.append(f"{missed} topic(s) could not be reached before your exam. "
                        "Increase your daily study time or remove some topics.")
    return {"sessions": sessions, "warnings": warnings}
