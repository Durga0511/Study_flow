@echo off
rem Double-click to start StudyFlow. Your phone can use the address printed below.
cd /d "%~dp0"
call venv\Scripts\activate.bat
start "" cmd /c "timeout /t 3 >nul & start http://127.0.0.1:5000"
python run_on_phone.py
pause
