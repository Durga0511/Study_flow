import calendar as pycal
import json
import os
import re
import secrets
import time
import sqlite3
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo
from functools import wraps

from flask import (Flask, abort, flash, has_request_context, redirect, render_template, request,
                   session, url_for, jsonify, send_from_directory)
from werkzeug.security import check_password_hash, generate_password_hash

import database
import gamify
import scheduler

app = Flask(__name__)
os.makedirs(database.INSTANCE, exist_ok=True)


def load_secret_key():
    """Use STUDYFLOW_SECRET if set; otherwise create a random key once and reuse it,
    so 'Remember Me' still works after you restart the server."""
    key = os.environ.get("STUDYFLOW_SECRET")
    if key:
        return key
    path = os.path.join(database.INSTANCE, "secret_key")
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(secrets.token_hex(32))
    with open(path) as f:
        return f.read().strip()


app.config.update(
    SECRET_KEY=load_secret_key(),
    SESSION_COOKIE_HTTPONLY=True,   # JavaScript cannot read the cookie
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=timedelta(days=30),  # used only when Remember Me is ticked
)
database.init_db()

# ---------- Hosting: secure cookies, proxy, headers, time zones, login protection ----------
if os.environ.get("STUDYFLOW_HTTPS") == "1":          # set when the site is served over https://
    app.config.update(SESSION_COOKIE_SECURE=True)
if os.environ.get("STUDYFLOW_PROXY") == "1":          # set when a hosting proxy sits in front of the app
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)


def user_now():
    """Current time in the visitor's time zone. The browser sends it in a cookie, so 'today' is right
    even when the server runs in another country. Falls back to STUDYFLOW_TZ, then the computer's clock."""
    names = [request.cookies.get("tz", "") if has_request_context() else "", os.environ.get("STUDYFLOW_TZ", "")]
    for name in names:
        if name:
            try:
                return datetime.now(ZoneInfo(name)).replace(tzinfo=None)
            except Exception:  # unknown name, or no time zone database installed: try the next option
                pass
    return datetime.now()


def today_date():
    return user_now().date()


@app.after_request
def security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    if request.is_secure:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
    if request.endpoint not in ("static", "service_worker", "manifest"):
        response.headers["Cache-Control"] = "no-store"  # a shared laptop must not show your pages after logout
    return response


FAILED_LOGINS = {}  # (email, ip) -> times of recent failed logins


def too_many_attempts(key):
    now = time.time()
    if len(FAILED_LOGINS) > 5000:
        FAILED_LOGINS.clear()
    recent = [t for t in FAILED_LOGINS.get(key, []) if now - t < 600]
    FAILED_LOGINS[key] = recent
    return len(recent) >= 5


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# ---------- CSRF protection: every POST form must carry the session's token ----------
def csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(16)
    return session["csrf_token"]


app.jinja_env.globals["csrf_token"] = csrf_token


@app.before_request
def check_csrf():
    if request.method == "POST":
        sent = request.form.get("csrf_token", "")
        if not sent or not secrets.compare_digest(sent, session.get("csrf_token", "")):
            abort(400, "Invalid form token. Go back, refresh the page and try again.")


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in first.")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


# ---------- Pages ----------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        error, user_id = None, None
        if not 2 <= len(name) <= 80:
            error = "Please enter your full name."
        elif not EMAIL_RE.match(email) or len(email) > 254:
            error = "Please enter a valid email address."
        elif len(password) < 8:
            error = "Password must be at least 8 characters."
        elif password != confirm:
            error = "Passwords do not match."
        if not error:
            db = database.get_db()
            try:
                cur = db.execute(
                    "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
                    (name, email, generate_password_hash(password)))
                user_id = cur.lastrowid
                db.execute("INSERT INTO preferences (user_id) VALUES (?)", (user_id,))
                db.execute("INSERT INTO settings (user_id, theme) VALUES (?, 'dark')", (user_id,))
                db.commit()
            except sqlite3.IntegrityError:
                error = "That email is already registered. Try logging in."
            finally:
                db.close()
        if not error:
            session.clear()
            session["user_id"] = user_id
            return redirect(url_for("dashboard"))
        flash(error)
    return render_template("signup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        key = (email, request.remote_addr)
        if too_many_attempts(key):
            flash("Too many failed attempts. Please wait 10 minutes and try again.")
            return render_template("login.html"), 429
        db = database.get_db()
        user = db.execute("SELECT id, password_hash FROM users WHERE email = ?",
                          (email,)).fetchone()
        db.close()
        if user and check_password_hash(user["password_hash"], password):
            FAILED_LOGINS.pop(key, None)
            session.clear()
            session["user_id"] = user["id"]
            session.permanent = bool(request.form.get("remember"))
            return redirect(url_for("dashboard"))
        FAILED_LOGINS.setdefault(key, []).append(time.time())
        flash("Incorrect email or password.")
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()  # removes the login only; saved data stays in the database
    return redirect(url_for("index"))


# ---------- Setup wizard ----------
TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


@app.template_filter("hm")
def format_minutes(total):
    hours, minutes = divmod(int(total), 60)
    if hours and minutes:
        return f"{hours} h {minutes} min"
    return f"{hours} h" if hours else f"{minutes} min"


@app.template_filter("ampm")
def format_time(value):
    hour, minute = map(int, value.split(":"))
    return f"{(hour % 12) or 12}:{minute:02d} {'AM' if hour < 12 else 'PM'}"


def to_int(text):
    try:
        return int(text)
    except (TypeError, ValueError):
        return None


def validate_setup(form):
    """Re-check every wizard answer on the server. Returns (error_message, values)."""
    name = form.get("exam_name", "").strip()
    description = form.get("exam_description", "").strip()
    start = form.get("start_time", "")
    try:
        exam_date = date.fromisoformat(form.get("exam_date", ""))
    except ValueError:
        exam_date = None
    daily = to_int(form.get("daily_minutes"))
    focus = to_int(form.get("focus_minutes"))
    short = to_int(form.get("short_break"))
    long_break = to_int(form.get("long_break"))
    after = to_int(form.get("long_break_after"))
    error = None
    if not 1 <= len(name) <= 100:
        error = "Please enter an exam name (up to 100 characters)."
    elif len(description) > 500:
        error = "The description can be at most 500 characters."
    elif exam_date is None:
        error = "Please choose a valid exam date."
    elif exam_date < today_date():
        error = "The exam date cannot be in the past."
    elif daily is None or not 15 <= daily <= 960:
        error = "Daily study time must be between 15 minutes and 16 hours."
    elif focus is None or not 5 <= focus <= 180:
        error = "Focus stretch must be between 5 and 180 minutes."
    elif focus > daily:
        error = "Your focus stretch cannot be longer than your daily study time."
    elif short not in (5, 10, 15):
        error = "Short break must be 5, 10 or 15 minutes."
    elif long_break not in (30, 60):
        error = "Long break must be 30 or 60 minutes."
    elif after is None or not 1 <= after <= 10:
        error = "Choose when the long break should happen (after 1 to 10 sessions)."
    elif not TIME_RE.match(start):
        error = "Please choose a valid start time."
    values = (name, exam_date.isoformat() if exam_date else "", description,
              daily, focus, short, long_break, after, start)
    return error, values


@app.route("/setup", methods=["GET", "POST"])
@login_required
def setup():
    uid = session["user_id"]
    if request.method == "POST":
        error, v = validate_setup(request.form)
        if error:
            flash(error)
        else:
            db = database.get_db()
            try:
                first = db.execute("SELECT setup_done FROM settings WHERE user_id = ?",
                                   (uid,)).fetchone()["setup_done"] == 0
                db.execute(
                    "INSERT INTO exams (user_id, name, exam_date, description) VALUES (?, ?, ?, ?) "
                    "ON CONFLICT(user_id) DO UPDATE SET name = excluded.name, "
                    "exam_date = excluded.exam_date, description = excluded.description",
                    (uid, v[0], v[1], v[2]))
                db.execute(
                    "UPDATE preferences SET daily_minutes = ?, focus_minutes = ?, short_break = ?, "
                    "long_break = ?, long_break_after = ?, start_time = ? WHERE user_id = ?",
                    (*v[3:], uid))
                db.execute("UPDATE settings SET setup_done = 1 WHERE user_id = ?", (uid,))
                db.commit()
            finally:
                db.close()
            if first:
                session["celebrate"] = True  # confetti once, on the first completed setup
            return redirect(url_for("dashboard"))
    db = database.get_db()
    try:
        exam = db.execute("SELECT name, exam_date, description FROM exams WHERE user_id = ?",
                          (uid,)).fetchone()
        prefs = db.execute("SELECT * FROM preferences WHERE user_id = ?", (uid,)).fetchone()
    finally:
        db.close()
    return render_template("setup.html", exam=exam, prefs=prefs, today=today_date().isoformat())


@app.route("/dashboard")
@login_required
def dashboard():
    uid = session["user_id"]
    db = database.get_db()
    try:
        user = db.execute("SELECT name, email, created_at FROM users WHERE id = ?", (uid,)).fetchone()
        if user is None:  # account no longer exists
            session.clear()
            return redirect(url_for("login"))
        settings = db.execute("SELECT setup_done FROM settings WHERE user_id = ?", (uid,)).fetchone()
        if not settings or not settings["setup_done"]:
            return redirect(url_for("setup"))  # first login: run the wizard
        exam = db.execute("SELECT name, exam_date, description FROM exams WHERE user_id = ?",
                          (uid,)).fetchone()
        prefs = db.execute("SELECT * FROM preferences WHERE user_id = ?", (uid,)).fetchone()
        day_rows = db.execute(
            "SELECT duration_min, status FROM study_sessions WHERE user_id = ? AND session_date = ? "
            "AND kind IN ('study', 'revision', 'practice')", (uid, today_date().isoformat())).fetchall()
        dragon = dragon_stats(db, uid)
    finally:
        db.close()
    planned = sum(r["duration_min"] for r in day_rows)
    done_min = sum(r["duration_min"] for r in day_rows if r["status"] == "completed")
    n_done = sum(1 for r in day_rows if r["status"] == "completed")
    today_stats = {"total": len(day_rows), "done": n_done, "planned": planned, "done_min": done_min,
                   "left": planned - done_min, "pct": round(n_done / len(day_rows) * 100) if day_rows else 0}
    exam_day = date.fromisoformat(exam["exam_date"])
    days_left = (exam_day - today_date()).days
    started = date.fromisoformat(user["created_at"][:10])
    total = (exam_day - started).days
    if days_left <= 0:
        pct = 100
    elif total <= 0:
        pct = 0
    else:
        pct = max(0, min(100, round((total - days_left) / total * 100)))
    return render_template(
        "dashboard.html", user=user, exam=exam, prefs=prefs, days_left=days_left,
        weeks=max(days_left, 0) // 7, extra_days=max(days_left, 0) % 7, pct=pct,
        exam_text=exam_day.strftime("%A, %d %B %Y"), celebrate=session.pop("celebrate", False), today_stats=today_stats, dragon=dragon)


# ---------- Subjects and topics ----------
LEVELS = ("Easy", "Medium", "Hard")
PRIORITIES = ("Low", "Medium", "High")


def back_to(subject_id):
    return redirect(url_for("subjects") + f"#subject-{subject_id}")


def owned_subject(db, subject_id):
    """Fetch a subject only if it belongs to the logged-in user, otherwise 404."""
    row = db.execute("SELECT * FROM subjects WHERE id = ? AND user_id = ?",
                     (subject_id, session["user_id"])).fetchone()
    if row is None:
        abort(404)
    return row


def parse_subject(form, db, uid, subject_id=None):
    name = form.get("name", "").strip()
    notes = form.get("notes", "").strip()
    difficulty, priority = form.get("difficulty"), form.get("priority")
    raw = form.get("hours", "").strip()
    try:
        hours = float(raw) if raw else 0.0  # blank means: let StudyFlow decide
    except ValueError:
        hours = None
    error = None
    if not 1 <= len(name) <= 80:
        error = "Please enter a subject name (up to 80 characters)."
    elif difficulty not in LEVELS:
        error = "Choose a difficulty: Easy, Medium or Hard."
    elif priority not in PRIORITIES:
        error = "Choose a priority: Low, Medium or High."
    elif hours is None or not (hours == 0 and not raw or 0.25 <= hours <= 500):
        error = "Total hours must be between 0.25 and 500, or leave it blank."
    elif len(notes) > 500:
        error = "Notes can be at most 500 characters."
    elif db.execute("SELECT id FROM subjects WHERE user_id = ? AND lower(name) = lower(?) AND id != ?",
                    (uid, name, subject_id or 0)).fetchone():
        error = "You already have a subject with that name."
    minutes = round(hours * 60) if hours is not None and error is None else 0
    return error, (name, difficulty, priority, minutes, notes)


@app.route("/subjects")
@login_required
def subjects():
    uid = session["user_id"]
    db = database.get_db()
    try:
        rows = db.execute("SELECT * FROM subjects WHERE user_id = ? ORDER BY name COLLATE NOCASE",
                          (uid,)).fetchall()
        topics = db.execute("SELECT * FROM topics WHERE user_id = ? ORDER BY id", (uid,)).fetchall()
    finally:
        db.close()
    cards = []
    for s in rows:
        mine = [t for t in topics if t["subject_id"] == s["id"]]
        done = sum(t["completed"] for t in mine)
        cards.append({"subject": s, "topics": mine, "done": done, "total": len(mine),
                      "pct": round(done / len(mine) * 100) if mine else 0})
    return render_template("subjects.html", cards=cards)


def save_subject(subject_id):
    uid = session["user_id"]
    db = database.get_db()
    try:
        subject = owned_subject(db, subject_id) if subject_id else None
        if request.method == "POST":
            error, v = parse_subject(request.form, db, uid, subject_id)
            lines = [] if subject else [x.strip() for x in request.form.get("topics", "").splitlines() if x.strip()]
            if not error and (len(lines) > 60 or any(len(x) > 100 for x in lines)):
                error = "Add up to 60 topics, each up to 100 characters."
            if error:
                flash(error)
            elif subject:
                db.execute("UPDATE subjects SET name = ?, difficulty = ?, priority = ?, est_minutes = ?, "
                           "notes = ? WHERE id = ? AND user_id = ?", (*v, subject_id, uid))
                db.commit()
                return back_to(subject_id)
            else:
                cur = db.execute("INSERT INTO subjects (user_id, name, difficulty, priority, est_minutes, notes) "
                                 "VALUES (?, ?, ?, ?, ?, ?)", (uid, *v))
                new_id = cur.lastrowid
                each = 45  # topics need no time of their own: the planner shares study time between them
                db.executemany("INSERT INTO topics (user_id, subject_id, name, est_minutes) VALUES (?, ?, ?, ?)",
                               [(uid, new_id, x, each) for x in lines])
                db.commit()
                return back_to(new_id)
    finally:
        db.close()
    return render_template("subject_form.html", subject=subject)


@app.route("/subjects/new", methods=["GET", "POST"])
@login_required
def new_subject():
    return save_subject(None)


@app.route("/subjects/<int:subject_id>/edit", methods=["GET", "POST"])
@login_required
def edit_subject(subject_id):
    return save_subject(subject_id)


@app.route("/subjects/<int:subject_id>/delete", methods=["POST"])
@login_required
def delete_subject(subject_id):
    db = database.get_db()
    try:
        owned_subject(db, subject_id)
        db.execute("DELETE FROM subjects WHERE id = ? AND user_id = ?", (subject_id, session["user_id"]))
        db.commit()  # its topics are removed automatically (ON DELETE CASCADE)
    finally:
        db.close()
    return redirect(url_for("subjects"))


@app.route("/subjects/<int:subject_id>/topics", methods=["POST"])
@login_required
def add_topic(subject_id):
    uid = session["user_id"]
    name = request.form.get("name", "").strip()
    db = database.get_db()
    try:
        owned_subject(db, subject_id)
        count = db.execute("SELECT COUNT(*) FROM topics WHERE subject_id = ?", (subject_id,)).fetchone()[0]
        if not 1 <= len(name) <= 100:
            flash("Topic name must be 1 to 100 characters.")
        elif count >= 60:
            flash("A subject can have at most 60 topics.")
        else:
            db.execute("INSERT INTO topics (user_id, subject_id, name) VALUES (?, ?, ?)", (uid, subject_id, name))
            db.commit()
    finally:
        db.close()
    return back_to(subject_id)


def owned_topic(db, topic_id):
    row = db.execute("SELECT subject_id FROM topics WHERE id = ? AND user_id = ?",
                     (topic_id, session["user_id"])).fetchone()
    if row is None:
        abort(404)
    return row["subject_id"]


@app.route("/topics/<int:topic_id>/toggle", methods=["POST"])
@login_required
def toggle_topic(topic_id):
    db = database.get_db()
    try:
        subject_id = owned_topic(db, topic_id)
        done = 1 if request.form.get("completed") else 0  # an unticked checkbox sends nothing
        db.execute("UPDATE topics SET completed = ? WHERE id = ? AND user_id = ?",
                   (done, topic_id, session["user_id"]))
        db.commit()
    finally:
        db.close()
    return back_to(subject_id)


@app.route("/topics/<int:topic_id>/delete", methods=["POST"])
@login_required
def delete_topic(topic_id):
    db = database.get_db()
    try:
        subject_id = owned_topic(db, topic_id)
        db.execute("DELETE FROM topics WHERE id = ? AND user_id = ?", (topic_id, session["user_id"]))
        db.commit()
    finally:
        db.close()
    return back_to(subject_id)


# ---------- Planner: generate the plan, show the timetable, checklist and notes ----------
STUDY_KINDS = ("study", "revision", "practice")
STATUSES = (("not_started", "Not Started"), ("in_progress", "In Progress"), ("completed", "Completed"))
KIND_LABELS = {"study": "Study", "revision": "Revision", "practice": "Practice test"}


def parse_day(text):
    try:
        return date.fromisoformat(text or "")
    except ValueError:
        return today_date()


def back_to_planner(day, session_id=None):
    return redirect(url_for("planner", day=day.isoformat()) + (f"#session-{session_id}" if session_id else ""))


@app.route("/planner")
@login_required
def planner():
    uid = session["user_id"]
    day = parse_day(request.args.get("day"))
    db = database.get_db()
    try:
        rows = db.execute("SELECT * FROM study_sessions WHERE user_id = ? AND session_date = ? "
                          "ORDER BY start_time, id", (uid, day.isoformat())).fetchall()
        has_any = db.execute("SELECT 1 FROM study_sessions WHERE user_id = ? LIMIT 1", (uid,)).fetchone()
    finally:
        db.close()
    study = [r for r in rows if r["kind"] in STUDY_KINDS]
    done = [r for r in study if r["status"] == "completed"]
    planned, done_min = sum(r["duration_min"] for r in study), sum(r["duration_min"] for r in done)
    return render_template(
        "planner.html", sessions=rows, day=day, today=today_date(), has_any=bool(has_any),
        prev_day=(day - timedelta(days=1)).isoformat(), next_day=(day + timedelta(days=1)).isoformat(),
        n_study=len(study), n_done=len(done), planned=planned, done_min=done_min,
        pct=round(len(done) / len(study) * 100) if study else 0, statuses=STATUSES, kinds=KIND_LABELS)


@app.route("/planner/generate", methods=["POST"])
@login_required
def generate_plan():
    uid = session["user_id"]
    routine = request.form.get("style") == "routine"  # same timetable every day
    db = database.get_db()
    try:
        ready = db.execute("SELECT setup_done FROM settings WHERE user_id = ?", (uid,)).fetchone()
        if not ready or not ready["setup_done"]:
            return redirect(url_for("setup"))
        exam = db.execute("SELECT exam_date FROM exams WHERE user_id = ?", (uid,)).fetchone()
        prefs = db.execute("SELECT * FROM preferences WHERE user_id = ?", (uid,)).fetchone()
        subjects = []
        for row in db.execute("SELECT id, name, difficulty, priority, est_minutes FROM subjects WHERE user_id = ?", (uid,)):
            subjects.append({**dict(row), "topics": []})
        by_id = {s["id"]: s for s in subjects}
        for t in db.execute("SELECT id, subject_id, name, completed FROM topics WHERE user_id = ? ORDER BY id", (uid,)):
            by_id[t["subject_id"]]["topics"].append(dict(t))
        today = today_date()
        completed = {r["session_date"]: (r["minutes"], r["last_end"]) for r in db.execute(
            "SELECT session_date, SUM(duration_min) AS minutes, MAX(end_time) AS last_end FROM study_sessions "
            "WHERE user_id = ? AND session_date >= ? AND status = 'completed' GROUP BY session_date",
            (uid, today.isoformat()))}
        now = user_now()
        plan = scheduler.generate_plan(dict(prefs), date.fromisoformat(exam["exam_date"]), today,
                                       now.hour * 60 + now.minute, subjects, completed, routine)
        # Completed sessions stay; everything unfinished from today onward is replaced.
        db.execute("DELETE FROM study_sessions WHERE user_id = ? AND session_date >= ? AND status != 'completed'",
                   (uid, today.isoformat()))
        db.executemany(
            "INSERT INTO study_sessions (user_id, topic_id, title, kind, session_date, start_time, end_time, "
            "duration_min) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [(uid, x["topic_id"], x["title"], x["kind"], x["date"], x["start"], x["end"], x["minutes"])
             for x in plan["sessions"]])
        db.commit()
    finally:
        db.close()
    for warning in plan["warnings"]:
        flash(warning)
    return redirect(url_for("planner"))


@app.route("/sessions/<int:session_id>/start", methods=["POST"])
@login_required
def start_session(session_id):
    """'Start studying': mark the session In Progress and open the timer for it."""
    db = database.get_db()
    try:
        row = owned_session(db, session_id)
        if row["kind"] not in STUDY_KINDS:
            abort(400)
        if row["status"] != "completed":
            db.execute("UPDATE study_sessions SET status = 'in_progress' WHERE id = ? AND user_id = ?",
                       (session_id, session["user_id"]))
            db.commit()
    finally:
        db.close()
    return redirect(url_for("timer", session=session_id))


def owned_session(db, session_id):
    row = db.execute("SELECT * FROM study_sessions WHERE id = ? AND user_id = ?",
                     (session_id, session["user_id"])).fetchone()
    if row is None:
        abort(404)
    return row


@app.route("/sessions/<int:session_id>/status", methods=["POST"])
@login_required
def set_status(session_id):
    status = request.form.get("status")
    if status not in [key for key, _ in STATUSES]:
        abort(400)
    uid = session["user_id"]
    db = database.get_db()
    try:
        row = owned_session(db, session_id)
        if row["kind"] not in STUDY_KINDS:
            abort(400)  # breaks have no checklist
        db.execute("UPDATE study_sessions SET status = ? WHERE id = ? AND user_id = ?", (status, session_id, uid))
        # Study history is rebuilt every time, so repeated clicks can never double-count minutes.
        db.execute("DELETE FROM study_history WHERE session_id = ? AND user_id = ? AND source = 'checklist'",
                   (session_id, uid))
        if status == "completed":
            db.execute("INSERT INTO study_history (user_id, session_id, studied_on, minutes, source) "
                       "VALUES (?, ?, ?, ?, 'checklist')", (uid, session_id, today_date().isoformat(), row["duration_min"]))
        db.commit()
    finally:
        db.close()
    return back_to_planner(parse_day(row["session_date"]), session_id)


@app.route("/sessions/<int:session_id>/notes", methods=["POST"])
@login_required
def save_notes(session_id):
    notes = request.form.get("notes", "").strip()
    db = database.get_db()
    try:
        row = owned_session(db, session_id)
        if len(notes) > 1000:
            flash("Notes can be at most 1000 characters.")
        else:
            db.execute("UPDATE study_sessions SET notes = ? WHERE id = ? AND user_id = ?",
                       (notes, session_id, session["user_id"]))
            db.commit()
    finally:
        db.close()
    return back_to_planner(parse_day(row["session_date"]), session_id)


# ---------- Dragon companion, timer, calendar and settings ----------
@app.context_processor
def inject_theme():
    """Logged-in users get their saved theme on every device."""
    if "user_id" not in session:
        return {}
    db = database.get_db()
    try:
        row = db.execute("SELECT theme, notifications FROM settings WHERE user_id = ?", (session["user_id"],)).fetchone()
        prefs = db.execute("SELECT focus_minutes, short_break, long_break, long_break_after FROM preferences "
                           "WHERE user_id = ?", (session["user_id"],)).fetchone()
    finally:
        db.close()
    info = {"user_theme": row["theme"] if row else None}
    if prefs:  # the timer runs on every page, so every page gets its settings
        info["timer_cfg"] = {"uid": session["user_id"], "focus": prefs["focus_minutes"], "short": prefs["short_break"],
                             "long": prefs["long_break"], "after": prefs["long_break_after"],
                             "notify": bool(row["notifications"]) if row else True, "url": url_for("timer_complete")}
    return info


def dragon_stats(db, uid):
    rows = db.execute("SELECT studied_on, SUM(minutes) AS m, COUNT(*) AS n FROM study_history "
                      "WHERE user_id = ? GROUP BY studied_on", (uid,)).fetchall()
    today = today_date()
    done = db.execute(
        "SELECT COUNT(*) FROM subjects s WHERE s.user_id = ? "
        "AND EXISTS (SELECT 1 FROM topics t WHERE t.subject_id = s.id) "
        "AND NOT EXISTS (SELECT 1 FROM topics t WHERE t.subject_id = s.id AND t.completed = 0)", (uid,)).fetchone()[0]
    return gamify.summary({date.fromisoformat(r["studied_on"]): r["m"] for r in rows},
                          sum(r["n"] for r in rows),
                          sum(r["n"] for r in rows if r["studied_on"] == today.isoformat()), done, today)


@app.route("/timer")
@login_required
def timer():
    uid = session["user_id"]
    db = database.get_db()
    try:
        info = None
        wanted = request.args.get("session", type=int)
        if wanted:
            row = db.execute("SELECT id, title, duration_min FROM study_sessions WHERE id = ? AND user_id = ? "
                             "AND kind IN ('study', 'revision', 'practice') AND status != 'completed'",
                             (wanted, uid)).fetchone()
            info = {"id": row["id"], "title": row["title"], "minutes": row["duration_min"]} if row else None
        prefs = db.execute("SELECT * FROM preferences WHERE user_id = ?", (uid,)).fetchone()
        notify = db.execute("SELECT notifications FROM settings WHERE user_id = ?", (uid,)).fetchone()
        today_min = db.execute("SELECT COALESCE(SUM(minutes), 0) FROM study_history WHERE user_id = ? "
                               "AND studied_on = ? AND source = 'timer'", (uid, today_date().isoformat())).fetchone()[0]
    finally:
        db.close()
    return render_template("timer.html", prefs=prefs, today_min=today_min, session_info=info,
                           notify=notify["notifications"] if notify else 1)


@app.route("/timer/complete", methods=["POST"])
@login_required
def timer_complete():
    uid = session["user_id"]
    token = request.form.get("token", "")
    minutes = to_int(request.form.get("minutes"))
    session_id = to_int(request.form.get("session_id")) if request.form.get("session_id") else None
    db = database.get_db()
    try:
        prefs = db.execute("SELECT focus_minutes FROM preferences WHERE user_id = ?", (uid,)).fetchone()
        row = None
        if session_id is not None:
            row = db.execute("SELECT id, duration_min FROM study_sessions WHERE id = ? AND user_id = ? "
                             "AND kind IN ('study', 'revision', 'practice')", (session_id, uid)).fetchone()
            if row is None:
                return jsonify(ok=False), 404
        limit = max(prefs["focus_minutes"], row["duration_min"] if row else 0)
        if not re.fullmatch(r"[a-f0-9]{12,40}", token) or minutes is None or not 1 <= minutes <= limit:
            return jsonify(ok=False), 400
        try:
            db.execute("INSERT INTO timer_runs (token, user_id) VALUES (?, ?)", (token, uid))
        except sqlite3.IntegrityError:  # the same run was sent twice: ignore it
            return jsonify(ok=True, duplicate=True)
        today = today_date().isoformat()
        if row and request.form.get("done") == "1":  # the timer ran the whole session: tick it off
            db.execute("UPDATE study_sessions SET status = 'completed' WHERE id = ? AND user_id = ?", (row["id"], uid))
            db.execute("DELETE FROM study_history WHERE session_id = ? AND user_id = ?", (row["id"], uid))
            db.execute("INSERT INTO study_history (user_id, session_id, studied_on, minutes, source) "
                       "VALUES (?, ?, ?, ?, 'timer')", (uid, row["id"], today, minutes))
        else:
            db.execute("INSERT INTO study_history (user_id, session_id, studied_on, minutes, source) "
                       "VALUES (?, NULL, ?, ?, 'timer')", (uid, today, minutes))
        db.commit()
    finally:
        db.close()
    return jsonify(ok=True, xp=minutes + gamify.XP_PER_SESSION)


@app.route("/calendar")
@login_required
def calendar_view():
    uid = session["user_id"]
    today = today_date()
    try:
        year, month = map(int, request.args.get("month", "").split("-"))
        if not 2000 <= year <= 2100:
            raise ValueError
        first = date(year, month, 1)
    except ValueError:
        first = today.replace(day=1)
    weeks = pycal.Calendar(0).monthdatescalendar(first.year, first.month)
    db = database.get_db()
    try:
        rows = db.execute("SELECT session_date, kind, status FROM study_sessions WHERE user_id = ? "
                          "AND session_date BETWEEN ? AND ?",
                          (uid, weeks[0][0].isoformat(), weeks[-1][-1].isoformat())).fetchall()
        exam = db.execute("SELECT exam_date FROM exams WHERE user_id = ?", (uid,)).fetchone()
    finally:
        db.close()
    counts = {}
    for r in rows:
        c = counts.setdefault(r["session_date"], {"done": 0, "up": 0, "missed": 0, "brk": 0})
        if r["kind"] not in STUDY_KINDS:
            c["brk"] += 1
        elif r["status"] == "completed":
            c["done"] += 1
        elif r["session_date"] < today.isoformat():
            c["missed"] += 1
        else:
            c["up"] += 1
    empty = {"done": 0, "up": 0, "missed": 0, "brk": 0}
    grid = [[{"day": d, "in_month": d.month == first.month, "today": d == today,
              "exam": bool(exam) and d.isoformat() == exam["exam_date"], **counts.get(d.isoformat(), empty)}
             for d in week] for week in weeks]
    return render_template("calendar.html", grid=grid, title=first.strftime("%B %Y"),
                           prev_month=(first - timedelta(days=1)).strftime("%Y-%m"),
                           next_month=(first + timedelta(days=32)).replace(day=1).strftime("%Y-%m"),
                           this_month=today.strftime("%Y-%m"))


@app.route("/settings")
@login_required
def settings():
    db = database.get_db()
    try:
        user = db.execute("SELECT name, email FROM users WHERE id = ?", (session["user_id"],)).fetchone()
        prefs = db.execute("SELECT theme, notifications FROM settings WHERE user_id = ?", (session["user_id"],)).fetchone()
    finally:
        db.close()
    return render_template("settings.html", user=user, prefs=prefs)


@app.route("/settings/profile", methods=["POST"])
@login_required
def settings_profile():
    name = request.form.get("name", "").strip()
    theme = request.form.get("theme")
    if not 2 <= len(name) <= 80 or theme not in ("light", "dark"):
        flash("Please enter your name (2 to 80 characters) and choose a theme.")
    else:
        db = database.get_db()
        try:
            db.execute("UPDATE users SET name = ? WHERE id = ?", (name, session["user_id"]))
            db.execute("UPDATE settings SET theme = ?, notifications = ? WHERE user_id = ?",
                       (theme, 1 if request.form.get("notifications") else 0, session["user_id"]))
            db.commit()
        finally:
            db.close()
        flash("Settings saved.", "ok")
    return redirect(url_for("settings"))


@app.route("/settings/theme", methods=["POST"])
@login_required
def settings_theme():
    theme = request.form.get("theme")
    if theme not in ("light", "dark"):
        abort(400)
    db = database.get_db()
    try:
        db.execute("UPDATE settings SET theme = ? WHERE user_id = ?", (theme, session["user_id"]))
        db.commit()
    finally:
        db.close()
    return "", 204


def password_ok(db, password):
    row = db.execute("SELECT password_hash FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    return bool(row) and check_password_hash(row["password_hash"], password)


@app.route("/settings/password", methods=["POST"])
@login_required
def settings_password():
    new, confirm = request.form.get("new", ""), request.form.get("confirm", "")
    db = database.get_db()
    try:
        if not password_ok(db, request.form.get("current", "")):
            flash("Your current password is incorrect.")
        elif len(new) < 8:
            flash("The new password must be at least 8 characters.")
        elif new != confirm:
            flash("The new passwords do not match.")
        else:
            db.execute("UPDATE users SET password_hash = ? WHERE id = ?",
                       (generate_password_hash(new), session["user_id"]))
            db.commit()
            flash("Password changed.", "ok")
    finally:
        db.close()
    return redirect(url_for("settings"))


@app.route("/settings/delete", methods=["POST"])
@login_required
def settings_delete():
    db = database.get_db()
    try:
        if request.form.get("confirm") != "DELETE" or not password_ok(db, request.form.get("password", "")):
            flash("Account not deleted. Enter your password and type DELETE exactly.")
            return redirect(url_for("settings"))
        db.execute("DELETE FROM users WHERE id = ?", (session["user_id"],))  # everything else cascades
        db.commit()
    finally:
        db.close()
    session.clear()
    flash("Your account and all its data were deleted.", "ok")
    return redirect(url_for("index"))


# ---------- App-like install (PWA) ----------
@app.route("/manifest.webmanifest")
def manifest():
    icons = [{"src": url_for("static", filename=f"icons/icon-{n}.png"), "sizes": f"{n}x{n}", "type": "image/png",
              "purpose": "any maskable"} for n in (192, 512)]
    data = {"id": "/", "name": "StudyFlow", "short_name": "StudyFlow", "start_url": "/dashboard", "scope": "/",
            "description": "Plan smart, study consistently and raise your dragon.", "display": "standalone",
            "orientation": "portrait-primary", "background_color": "#0c0e11", "theme_color": "#0c0e11", "icons": icons}
    return app.response_class(json.dumps(data), mimetype="application/manifest+json")


@app.route("/sw.js")
def service_worker():
    response = send_from_directory(app.static_folder, "sw.js", mimetype="application/javascript")
    response.headers["Cache-Control"] = "no-cache"
    response.headers["Service-Worker-Allowed"] = "/"
    return response


@app.route("/offline")
def offline():
    return render_template("offline.html")


if __name__ == "__main__":
    app.run(debug=True)
