"""Database helpers. The SQLite file lives in instance/, which Flask never serves to the browser."""
import os
import sqlite3

BASE = os.path.dirname(os.path.abspath(__file__))
INSTANCE = os.path.join(BASE, "instance")
DB_PATH = os.environ.get("STUDYFLOW_DB", os.path.join(INSTANCE, "studyflow.db"))

# Every table except users points at users(id), so each row belongs to one user.
# Daily tasks + completion status live in study_sessions.status.
SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS exams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    exam_date TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS preferences (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    daily_minutes INTEGER NOT NULL DEFAULT 120 CHECK (daily_minutes BETWEEN 15 AND 960),
    focus_minutes INTEGER NOT NULL DEFAULT 45 CHECK (focus_minutes BETWEEN 5 AND 180),
    short_break INTEGER NOT NULL DEFAULT 10 CHECK (short_break BETWEEN 1 AND 60),
    long_break INTEGER NOT NULL DEFAULT 30 CHECK (long_break BETWEEN 5 AND 120),
    long_break_after INTEGER NOT NULL DEFAULT 3 CHECK (long_break_after BETWEEN 1 AND 10),
    start_time TEXT NOT NULL DEFAULT '09:00'
);
CREATE TABLE IF NOT EXISTS settings (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    theme TEXT NOT NULL DEFAULT 'light' CHECK (theme IN ('light', 'dark')),
    notifications INTEGER NOT NULL DEFAULT 1,
    setup_done INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    difficulty TEXT NOT NULL DEFAULT 'Medium' CHECK (difficulty IN ('Easy', 'Medium', 'Hard')),
    priority TEXT NOT NULL DEFAULT 'Medium' CHECK (priority IN ('Low', 'Medium', 'High')),
    est_minutes INTEGER NOT NULL DEFAULT 60,
    notes TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    est_minutes INTEGER NOT NULL DEFAULT 45,
    completed INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS study_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    topic_id INTEGER REFERENCES topics(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'study'
        CHECK (kind IN ('study', 'revision', 'practice', 'short_break', 'long_break')),
    session_date TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    duration_min INTEGER NOT NULL,
    notes TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'not_started'
        CHECK (status IN ('not_started', 'in_progress', 'completed'))
);
CREATE TABLE IF NOT EXISTS study_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_id INTEGER REFERENCES study_sessions(id) ON DELETE SET NULL,
    studied_on TEXT NOT NULL,
    minutes INTEGER NOT NULL CHECK (minutes > 0),
    source TEXT NOT NULL CHECK (source IN ('checklist', 'timer'))
);
CREATE TABLE IF NOT EXISTS timer_runs (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""


def get_db():
    """Open a connection. Rows can be read like dictionaries: row['name']."""
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")  # SQLite ignores foreign keys unless this is set
    return db


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    db = get_db()
    db.executescript(SCHEMA)
    db.commit()
    db.close()


if __name__ == "__main__":
    init_db()
    print("Database ready at", DB_PATH)
